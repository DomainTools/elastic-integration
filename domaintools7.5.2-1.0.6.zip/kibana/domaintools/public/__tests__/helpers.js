import { Role, Selector } from 'testcafe';

const config = require('./config.json');

export const user = Role(config.baseUrl, async (t) => {
  await t
    .typeText(Selector('input').withAttribute('name', 'username'), config.username)
    .typeText(Selector('input').withAttribute('name', 'password'), config.password)
    .click('.euiButton.euiButton--primary.euiButton--fill');
});
