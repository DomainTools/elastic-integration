import { Selector } from 'testcafe';
import { user } from './helpers';
import {
  dashboardTitle,
  timeframeSelect,
  dangerousDomainsTitle,
  suspiciousDomainsTitle,
  youngDomainsTitle,
  eventsEnrichedTitle,
  threatPortfolioTitle,
  activeDomainsTitle,
  domainLookupsTitle,
  activeTagsTitle,
} from './selectors';

const config = require('./config.json');

fixture `Dashboard`

test('Confirm view dashboard', async t => {
  await t.useRole(user)
    .navigateTo(`${config.baseUrl}app/domaintools`)
    .expect(Selector(dashboardTitle).innerText).eql('Dashboard')
    .expect(Selector(timeframeSelect).innerText).eql('4 Hours')
    .expect(Selector(dangerousDomainsTitle).innerText).eql('Dangerous Domains')
    .expect(Selector(suspiciousDomainsTitle).innerText).eql('Suspicious Domains')
    .expect(Selector(youngDomainsTitle).innerText).eql('Young Domains')
    .expect(Selector(eventsEnrichedTitle).innerText).eql('Events Enriched')
    .expect(Selector(threatPortfolioTitle).innerText).eql('Threat Portfolio')
    .expect(Selector(activeDomainsTitle).innerText).eql('Active Domains')
    .expect(Selector(domainLookupsTitle).innerText).eql('Domain Lookups (Recent 20)')
    .expect(Selector(activeTagsTitle).innerText).eql('Active Tags')
});