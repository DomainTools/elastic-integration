import { Selector } from 'testcafe';
import { user } from './helpers';
import {
  appSaveSettingsBtn,
  appSettingsErrorForm,
  appSettingsLink,
  batchSizeInput,
  disableCacheCheckbox,
  domainAgeThresholdInput,
  enrichmentSettingsTitle,
  flushCacheBtn,
  pivotThresholdInput,
  proximityScoreThresholdInput,
  riskScoreThresholdInput,
  serviceUrlInput,
  settingsHeaderLink,
  threatIntelligenceSettingsTitle,
  threatProfileScoreThresholdInput,
  ttlCacheInput,
} from './selectors';

const config = require('./config.json');

fixture`AppSettings`
  .page(`${config.baseUrl}app/domaintools`)
  .beforeEach(async (t) => {
    await t.useRole(user)
      .click(settingsHeaderLink)
      .click(appSettingsLink);
  });

test('Check Service Setting Boundaries and Validation', async (t) => {
  await t
    .expect(Selector(enrichmentSettingsTitle).innerText).eql('Enrichment Settings')
    .typeText(batchSizeInput, '101', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Batch Size must be a number between 1-100')
    .typeText(batchSizeInput, '0', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Batch Size must be a number between 1-100')
    .selectText(batchSizeInput)
    .pressKey('delete')
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Batch Size must be a number between 1-100')
    .typeText(batchSizeInput, '1', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .typeText(batchSizeInput, '100', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
  // TTL Cache
    .typeText(ttlCacheInput, '0', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('TTL Cache must be a number greater than 0')
    .selectText(ttlCacheInput)
    .pressKey('delete')
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('TTL Cache must be a number greater than 0')
    .typeText(ttlCacheInput, '1', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .typeText(ttlCacheInput, '30', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
  // Disable Cache
    .click(disableCacheCheckbox)
    .debug()
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .click(disableCacheCheckbox)
    .debug()
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
});

test('Check Plugin Setting Boundaries and Validation', async (t) => {
  await t
    .expect(Selector(threatIntelligenceSettingsTitle).innerText).eql('Threat Intelligence Dashboard Settings')
    .typeText(riskScoreThresholdInput, '101', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Risk Score Threshold must be a number between 0-100')
    .typeText(riskScoreThresholdInput, '-1', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Risk Score Threshold must be a number between 0-100')
    .selectText(riskScoreThresholdInput)
    .pressKey('delete')
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Risk Score Threshold must be a number between 0-100')
    .typeText(riskScoreThresholdInput, '0', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .typeText(riskScoreThresholdInput, '100', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
  // Threat Profile Score Threshold
    .typeText(threatProfileScoreThresholdInput, '101', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Threat Profile Score Threshold must be a number between 0-100')
    .typeText(threatProfileScoreThresholdInput, '-1', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Threat Profile Score Threshold must be a number between 0-100')
    .selectText(threatProfileScoreThresholdInput)
    .pressKey('delete')
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Threat Profile Score Threshold must be a number between 0-100')
    .typeText(threatProfileScoreThresholdInput, '0', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .typeText(threatProfileScoreThresholdInput, '100', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
  // Proximity Score Threshold
    .typeText(proximityScoreThresholdInput, '101', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Proximity Score Threshold must be a number between 0-100')
    .typeText(proximityScoreThresholdInput, '-1', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Proximity Score Threshold must be a number between 0-100')
    .selectText(proximityScoreThresholdInput)
    .pressKey('delete')
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Proximity Score Threshold must be a number between 0-100')
    .typeText(proximityScoreThresholdInput, '0', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .typeText(proximityScoreThresholdInput, '100', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
  // Domain Age Threshold
    .typeText(domainAgeThresholdInput, '0', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Domain Age Threshold must be a number greater than 0')
    .selectText(domainAgeThresholdInput)
    .pressKey('delete')
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Domain Age Threshold must be a number greater than 0')
    .typeText(domainAgeThresholdInput, '1', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .typeText(domainAgeThresholdInput, '7', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
  // Pivot Threshold
    .typeText(pivotThresholdInput, '0', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Pivot Threshold must be a number greater than 0')
    .selectText(pivotThresholdInput)
    .pressKey('delete')
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).innerText)
    .contains('Pivot Threshold must be a number greater than 0')
    .typeText(pivotThresholdInput, '1', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk()
    .typeText(pivotThresholdInput, '500', { replace: true })
    .click(appSaveSettingsBtn)
    .expect(Selector(appSettingsErrorForm).exists)
    .notOk();
});

test('Flush Cache', async (t) => {
  await t
    .expect(Selector(enrichmentSettingsTitle).innerText).eql('Enrichment Settings')
    .click(flushCacheBtn);
});
