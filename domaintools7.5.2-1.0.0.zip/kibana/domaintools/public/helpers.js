import { useEffect, useRef } from 'react';

export async function fetchData(url, options = null) {
  let result = await fetch(url, options);
  let resultData = await result.json();
  return resultData;
}

export function audit(log_level, log_type, message, feature, source='DT UI Plugin', product='plugin') {
  const body = {
    "log_level": log_level,
    "log_type": log_type,
    "message": message,
    "feature": feature,
    "source": source,
    "product": product,
    "entry_timestamp": new Date().toISOString()
  }
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'kbn-xsrf': 'kibana',
    },
    body: JSON.stringify(body)
  };
  fetchData("../api/domaintools/es/dt-audit-alias", options);
}

export function useIsMountedRef(){
  const isMountedRef = useRef(null);
  useEffect(() => {
    isMountedRef.current = true;
    return () => isMountedRef.current = false;
  });
  return isMountedRef;
}