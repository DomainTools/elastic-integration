import React from 'react';
import { uiModules } from 'ui/modules';
import chrome from 'ui/chrome';
import { render, unmountComponentAtNode } from 'react-dom';
import { I18nProvider } from '@kbn/i18n/react';
import { EuiErrorBoundary } from '@elastic/eui';
import { audit, fetchData } from './helpers';

import 'ui/autoload/styles';
import { Main } from './components/main';

const app = uiModules.get('apps/domaintools');

app.config($locationProvider => {
  $locationProvider.html5Mode({
    enabled: false,
    requireBase: false,
    rewriteLinks: false,
  });
});
app.config(stateManagementConfigProvider => stateManagementConfigProvider.disable());
      

function RootController($scope, $element, $http) {
  const domNode = $element[0];
  const settingsDocumentId = "1";
  fetchData(`../api/domaintools/es/dt-settings/${settingsDocumentId}`)
  .then(response => {
    if(response.ok){
      if (response.data._source) {
        const source = response.data._source;
        const logIndices = source.log_indices;
        const indexPatterns = {
          'dt-enrichment*': 'last_enriched',
          'dt-settings*': '',
          'dt-audit*': 'entry_timestamp',
          'dt-metadata*': 'last_enriched_datetime'};
        if (logIndices) {
          logIndices.forEach(element => indexPatterns[element] = '@timestamp');
        }
        for (let [key, value] of Object.entries(indexPatterns)) {
          let body = {
            "title": key,
          }
          if (value) {
            body.timeFieldName = value
          }
          const url = chrome.addBasePath(`/api/saved_objects/index-pattern/${key}`);
          const delete_options = {
            method: 'DELETE',
            headers: {
              'Content-Type': 'application/json',
              'kbn-xsrf': 'kibana',
            }
          };
          fetch(url, delete_options) 
          .then(response => {
            if (response.status === 200 || response.status === 404) {
              audit("Debug", "Entry", `Successfully deleted index pattern ${key}`, "Startup", "DT UI Plugin");
              const create_options = {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'kbn-xsrf': 'kibana',
                },
                body: JSON.stringify({
                  "attributes": body
                })
              };
              fetch(url, create_options) 
              .then(response => {
                if (response.status === 200) {
                  audit("Debug", "Entry", `Successfully created index pattern ${key}`, "Startup", "DT UI Plugin");
                } else {
                  audit("Debug", "Error", `Error creating index pattern ${key}`, "Startup", "DT UI Plugin");
                }
              })
              .catch(error => audit("Debug", "Error", `Error creating index pattern ${key} | Detailed Error: ${error}`, "Startup", "DT UI Plugin"))
            } else {
              audit("Debug", "Error", `Error deleting index pattern ${key}`, "Startup", "DT UI Plugin");
            }
          })
          .catch(error => audit("Debug", "Error", `Error deleting index pattern ${key} | Detailed Error: ${error}`, "Startup", "DT UI Plugin"))
        }
      }
    } else {
      audit("Debug", "Entry", "Error getting settings", "Startup", "DT UI Plugin");
    }
  })
  .catch(error => audit("Debug", "Error", `Error gettings settings | Detailed Error: ${error}`, "Startup", "DT UI Plugin"))

  // render react to DOM
  render(
    <I18nProvider>
      <EuiErrorBoundary>
          <Main title="domaintools" httpClient={$http} />
      </EuiErrorBoundary>
    </I18nProvider>,
    domNode
  );

  // unmount react on controller destroy
  $scope.$on('$destroy', () => {
    unmountComponentAtNode(domNode);
  });
}

chrome.setRootController('domaintools', RootController);
