import React from 'react';
import { EuiHorizontalRule, EuiPageContentBody, EuiPageContentHeader, EuiTextAlign, EuiTitle } from '@elastic/eui';

export function CardPanel(props) {

  function textColor() {
    if ( typeof props.text_color !== 'undefined' ) {
      return props.text_color;
    }
    else {
      return "black";
    }
  }

  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle size="xxs">
          <h5>{props.title}</h5>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiHorizontalRule/>
        <EuiTextAlign textAlign="center">
          <EuiTitle size="l"><h1 style={{ color: textColor() }}>{props.value}</h1></EuiTitle>
        </EuiTextAlign>
      </EuiPageContentBody>
    </div>
  );
}
