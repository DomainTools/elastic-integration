import React from 'react';
import { EuiBasicTable, EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { GuidedPivotTextAndTooltip } from './guided_pivot_text_and_tooltip'

export function IPAddressTable(props) {
  const columns = [
    {
      field: 'address',
      name: 'Address',
      render: (address, item) => {
        return <GuidedPivotTextAndTooltip count={item.address_count} text={address} pivotThreshold={props.pivotThreshold} />
      },
    },
    {
      field: 'asns',
      name: 'ASN',
      render: asns => {
        return (
          <span>
            {
              asns
                .map(asn => <GuidedPivotTextAndTooltip count={asn.count} text={asn.value} pivotThreshold={props.pivotThreshold} />)
                .reduce((result, item) => <>{result}{", "}{item}</>)
            }
          </span>
        );
      },
    },
    {
      field: 'country_code',
      name: 'Country Code',
    },
    {
      field: 'isp',
      name: 'ISP',
    },
  ];

  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.ipAddressTableTitle"
              defaultMessage={props.title}/>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiBasicTable
          items={props.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
