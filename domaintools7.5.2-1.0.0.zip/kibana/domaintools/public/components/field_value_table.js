import React from 'react';
import { EuiBasicTable, EuiIconTip, EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { GuidedPivotTextAndTooltip } from './guided_pivot_text_and_tooltip'

export function FieldValueTable(props) {
  const columns = [
    {
      field: 'label',
      name: 'Field',
    },
    {
      field: 'value',
      name: 'Value',
      render: (value, item) => {
        return <GuidedPivotTextAndTooltip count={item.count} text={value} pivotThreshold={props.pivotThreshold} />
      },
    },
  ];


  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.fieldValueTableTitle"
              defaultMessage={props.title}/>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiBasicTable
          items={props.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
