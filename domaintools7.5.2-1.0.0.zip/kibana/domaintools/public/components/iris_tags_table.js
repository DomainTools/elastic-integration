import React from 'react';
import { EuiBasicTable, EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';

export function IrisTagsTable(props) {
  const columns = [
    {
      field: 'label',
      name: 'Label',
    },
    {
      field: 'tagged_at',
      name: 'Tagged On',
    },
    {
      field: 'tag_source',
      name: 'Tag Source',
    },
  ];

  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.irisTagsTableTitle"
              defaultMessage={props.title}/>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiBasicTable
          items={props.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
