import React from 'react';
import { EuiBasicTable, EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { GuidedPivotTextAndTooltip } from './guided_pivot_text_and_tooltip'

export function NameServerTable(props) {
  const columns = [
    {
      field: 'domain',
      name: 'Domain',
      render: (domain, item) => {
        return <GuidedPivotTextAndTooltip count={item.domain_count} text={domain} pivotThreshold={props.pivotThreshold} />
      },
    },
    {
      field: 'host',
      name: 'Host',
      render: (host, item) => {
        return <GuidedPivotTextAndTooltip count={item.host_count} text={host} pivotThreshold={props.pivotThreshold} />
      },
    },
    {
      field: 'ips',
      name: 'IPs',
      render: ips => {
        return (
          <span>
            {
              ips
                .map(ip => <GuidedPivotTextAndTooltip count={ip.count} text={ip.value} pivotThreshold={props.pivotThreshold} />)
                .reduce((result, item) => <>{result}{", "}{item}</>)
            }
          </span>
        );
      },
    },
  ];

  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.nameServerTableTitle"
              defaultMessage={props.title}/>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiBasicTable
          items={props.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
