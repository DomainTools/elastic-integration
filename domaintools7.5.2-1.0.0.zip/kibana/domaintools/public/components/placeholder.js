import React from 'react';
import {
  EuiHorizontalRule,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiText,
  EuiTextAlign,
  EuiTitle,
} from '@elastic/eui';

export function Placeholder(props) {
  return(
    <div>
      <EuiPageContentHeader>
        <EuiTitle size="xxs">
          <h5>{props.title}</h5>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiHorizontalRule />
        <EuiTextAlign textAlign="center">
          <EuiText>{props.text}</EuiText>
        </EuiTextAlign>
      </EuiPageContentBody>
    </div>
  )
}