import React, { Fragment, useState, useEffect } from 'react';
import {
  EuiCard,
  EuiIcon,
  EuiLoadingSpinner,
  EuiSpacer,
  EuiToolTip,
} from '@elastic/eui';
import chrome from 'ui/chrome';
import { Alert } from './alert';
import { audit, fetchData, useIsMountedRef } from '../helpers';

export function EventsEnriched(props) {
  const [isLoading, setIsLoading] = useState(true);
  const [eventsEnriched, setEventsEnriched] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getDomains() {
      if(props.timeframe && typeof props.settings !== 'undefined' && !_.isEmpty(props.settings)){
        const query = {
          "size": 0,
          "aggs": {
            "events": {
              "filter":
                {"range": {"@timestamp": {"gte": `now-${props.timeframe}/m`, "lt": "now/m"}}
              }
            }
          }
        };
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'kbn-xsrf': 'kibana',
          },
          body: JSON.stringify(query)
        };
        setIsLoading(true);
        const index = props.settings.log_indices ? props.settings.log_indices.join(',') : '*';
        const response = await fetchData(`../api/domaintools/es/${index}/search`, options);
        if (isMountedRef.current) {
          if(response.ok){
            if (response.data.aggregations) {
              setEventsEnriched(response.data.aggregations.events.doc_count);
            }
          } else {
            audit("Debug", "Error", "Error getting enriched events", "Dashboard", "DT UI Plugin");
            setAlerts([{message: response.error.msg, statusType: "danger"}])
          }
          setIsLoading(false);
        }
      }
    }
    getDomains();
  }, [props]);
  
  const handleOnClick = () => {
    const index = props.settings.log_indices ? props.settings.log_indices.join(',') : '*';
    const url = chrome.addBasePath(`/app/kibana#/discover?_g=(refreshInterval:(pause:!t,value:0),time:(from:now-${props.timeframe}%2Fm,to:now))&_a=(columns:!(_source),index:'${index}',interval:auto,query:(language:kuery,query:''),sort:!(!(_score,desc)))`);
    window.open(url, '_blank');
  }

  return(
    <Fragment>
      <Alert alerts={alerts} />
      {isLoading ? (
        <Fragment>
          <EuiSpacer size="l" />
          <EuiLoadingSpinner size="xl" />
        </Fragment>
      ) : (
        <EuiToolTip
          position="top"
          content={
            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
              Count of Events enriched by DomainTools App
            </p>
        }>
          <EuiCard
            data-id="eventsEnrichedTitle"
            icon={<EuiIcon size="xxl" type="list" color="secondary" />}
            title={<Fragment>{"Events Enriched"}<EuiSpacer size="xxl" /></Fragment>}
            description={
              <b style={{fontSize: 2.5 + 'rem'}}>{eventsEnriched}</b>
            }
            onClick={handleOnClick} />
        </EuiToolTip>
      )}
    </Fragment>
  )
}
