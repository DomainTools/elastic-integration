import React, { Fragment, useState, useEffect } from 'react';
import {
  EuiCard,
  EuiIcon,
  EuiLoadingSpinner,
  EuiSpacer,
  EuiToolTip,
} from '@elastic/eui';
import chrome from 'ui/chrome';
import { Alert } from './alert';
import { audit, fetchData, useIsMountedRef } from '../helpers';

export function YoungDomains(props) {
  const [isLoading, setIsLoading] = useState(true);
  const [youngDomains, setYoungDomains] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getDomains() {
      if(props.timeframe && !_.isEmpty(props.settings)){
        const domainAgeThreshold = props.settings.domain_age_threshold;
        const query = {
          "size": 0,
          "query": {
            "bool": {
              "filter": [
                {"range": {"@timestamp": {"gte": `now-${props.timeframe}/m`, "lt": "now/m"}}},
                {"range": {"DomainToolsIris.domain_create_date": {"gte": `now-${domainAgeThreshold}d/m`, "lt": "now/m"}}},
              ]
            }
          },
          "aggs": {
            "domains": {
              "cardinality": { "field": "_id" }
            }
          }
        };
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'kbn-xsrf': 'kibana',
          },
          body: JSON.stringify(query)
        };
        setIsLoading(true);
        const response = await fetchData("../api/domaintools/es/dt-enrichment/search", options);
        if (isMountedRef.current) {
          if(response.ok){
            if (response.data.aggregations) {
              setYoungDomains(response.data.aggregations.domains.value);
            }
          } else {
            audit("Debug", "Error", "Error getting young domains", "Dashboard", "DT UI Plugin");
            setAlerts([{message: response.error.msg, statusType: "danger"}])
          }
          setIsLoading(false);
        }
      }
    }
    getDomains();
  }, [props]);
  
  const handleOnClick = () => {
    const daysBefore = new Date(Date.now() - props.settings.domain_age_threshold * 24 * 60 * 60 * 1000).toISOString();
    const url = chrome.addBasePath(`/app/kibana#/discover?_g=(refreshInterval:(pause:!t,value:0),time:(from:now-${props.timeframe}%2Fm,to:now))&_a=(columns:!(_source),index:'dt-enrichment*',interval:auto,query:(language:kuery,query:'DomainToolsIris.domain_create_date%3Enow-${props.settings.domain_age_threshold}d'),sort:!(!(_score,desc)))`);
    window.open(url, '_blank');
  }

  return(
    <Fragment>
      <Alert alerts={alerts} />
      {isLoading ? (
        <Fragment>
          <EuiSpacer size="l" />
          <EuiLoadingSpinner size="xl" />
        </Fragment>
      ) : (
        <EuiToolTip
          position="top"
          content={
            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
              Count of Unique Domains with Domain Age less than configured threshold for young domains
            </p>
        }>
          <EuiCard
            data-id="youngDomainsTitle"
            icon={<EuiIcon size="xxl" type="cloudSunny" color="primary" />}
            title={<Fragment>{"Young Domains"}<EuiSpacer size="xxl" /></Fragment>}
            description={
              <b style={{fontSize: 2.5 + 'rem'}}>{youngDomains}</b>
            }
            onClick={handleOnClick} />
        </EuiToolTip>
      )}
    </Fragment>
  )
}