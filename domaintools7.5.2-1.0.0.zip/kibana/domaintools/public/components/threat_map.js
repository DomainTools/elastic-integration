import React, { useState, Fragment } from 'react';
import { EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { EmbeddedMap } from '../../../../x-pack/legacy/plugins/siem/public/components/embeddables/embedded_map';
import { Loader } from '../../../../x-pack/legacy/plugins/siem/public/components/loader';
import { FormattedMessage } from '@kbn/i18n/react';
import { Alert } from './alert';

export function ThreatMap() {
  const [alerts, setAlerts] = useState([]);

  return (
    <Fragment>
      <Alert alerts={alerts} />
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage id="domaintoolsPlugin.threatMapTitle" defaultMessage="Threat Map" />
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody />
    </Fragment>
  );
}
