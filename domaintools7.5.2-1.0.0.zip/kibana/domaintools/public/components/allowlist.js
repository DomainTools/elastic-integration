import React, { useState, useEffect, Fragment } from 'react';
import { formatDate } from '@elastic/eui/lib/services/format';

import {
  EuiBasicTable,
  EuiButton,
  EuiConfirmModal,
  EuiFieldSearch,
  EuiFieldText,
  EuiFlexGroup,
  EuiFlexItem,
  EuiForm,
  EuiFormRow,
  EuiIconTip,
  EuiLoadingSpinner,
  EuiOverlayMask,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiSpacer,
  EuiText,
  EuiTitle,
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';

export function Allowlist() {
  const [modalState, setModalState] = useState({
    isModalVisible: false,
  });
  const [extractedDomainsFromSubdomains, setExtractedDomainsFromSubdomains] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState("unknown");
  const [alerts, setAlerts] = useState([]);
  const [domains, setDomains] = useState([]);
  const [duplicateDomains, setDuplicateDomains] = useState([]);
  const [settings, setSettings] = useState({});
  const [originalAllowlist, setOriginalAllowlist] = useState([]);
  const [allowlist, setAllowlist] = useState([]);
  const [errors, setErrors] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const [subdomains, setSubdomains] = useState([]);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 20,
    totalItemCount: 0,
    hidePerPageOptions: true
  });
  const [sorting, setSorting] = useState({
    sort: {
      field: 'addedOn',
      direction: 'desc'
    },
  });
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getSettings() {
      const settingsDocumentId = "1";
      const response = await fetchData(`../api/domaintools/es/dt-settings/${settingsDocumentId}`);
      if (isMountedRef.current){
        if (response.ok) {
          if (response.data._source) {
            setSettings(response.data._source);
          }
        } else {
          audit("Debug", "Error", "Error getting settings", "Allowlist", "DT UI Plugin");
          setAlerts([{ message: response.error, statusType: 'danger' }]);
        }
      }
    }
    getSettings();
  }, []);

  useEffect(() => {
    async function getCurrentUser() {
      const sessionInfo = await fetchData("../api/security/v1/me");
      if (isMountedRef.current){
        setCurrentUser(sessionInfo.username || "unknown");
      }
    }
    getCurrentUser();
  }, []);

  useEffect(() => {
    async function getAllowlistDomains() {
      setIsLoading(true);
      const query = {
        "size": 1000,
        "_source": ["attribute_name", "allowlist_added_by", "allowlist_added_on", "allowlisted"],
        "query": {
          "bool": {
            "must": [
              {"term": {"allowlisted": {"value": true}}},
              {"term": {"attribute_type": {"value": "domain"}}}
            ]
          }
        },
        "sort" : [
          { "allowlist_added_on" : {"order" : "desc"}}
        ]
      };
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify(query)
      };
      setIsLoading(true);
      const domains = await fetchData("../api/domaintools/es/dt-metadata/search", options);
      if (isMountedRef.current){
        if(domains.ok){
          if (domains.data.hits.hits.length > 0) {
            const esAllowlist = domains.data.hits.hits.map(
              domain => ({
                domainName: domain._source.attribute_name,
                addedOn: domain._source.allowlist_added_on,
                addedBy: domain._source.allowlist_added_by
              }
            ))
            setOriginalAllowlist(esAllowlist);
            setAllowlist(esAllowlist);
            setPagination({ ...pagination, totalItemCount: esAllowlist.length });
          };
        } else {
          audit("Debug", "Error", "Error getting allowlisted domains", "Allowlist", "DT UI Plugin");
          setAlerts([{message: domains.error.msg, statusType: "danger"}])
        }
        setIsLoading(false);
      }
    }
    getAllowlistDomains();
  }, []);
  
  const onTableChange = ({ page = {}, sort = {} }) => {
    const { index: pageIndex, size: pageSize } = page;
    const { field: sortField, direction: sortDirection } = sort;

    setSelectedItems([]);
    setPagination({
      pageIndex,
      pageSize,
      totalItemCount: allowlist.length,
      hidePerPageOptions: true
    }),
    setSorting({
      sort: {
        field: sortField,
        direction: sortDirection
    }})
  };

  const onSelectionChange = selectedItems => {
    setSelectedItems(selectedItems);
  };

  const removeDomainsFromAllowlist = async () => {
    let body = ""
    selectedItems.forEach(async domain => {
      body += 
        `{"update":{"_index":"dt-metadata","_id":"${domain.domainName}"}}\r\n{"script":{"source":"ctx._source.allowlisted=params.allowlisted;ctx._source.allowlist_added_on=params.addedOn;ctx._source.allowlist_added_by=params.addedBy;ctx._source.attribute_type=params.attributeType;ctx._source.attribute_name=params.attributeName","lang":"painless","params": {"allowlisted":false,"addedOn":null,"addedBy":"","attributeType":"Domain","attributeName":"${domain.domainName}"}},"upsert":{"allowlisted":false,"allowlist_added_on":null,"allowlist_added_by":"","attribute_name":"${domain.domainName}","attribute_type":"Domain"}}\r\n`
    })
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain',
        'kbn-xsrf': 'kibana',
      },
      body: body
    };
    let response = await fetchData(`../api/domaintools/allowlist`, options);
    if(response.ok){
      const newAllowlist = _.differenceBy(allowlist, selectedItems, "domainName");
      const sortedData = newAllowlist.sort((a, b) => new Date(b.addedOn) - new Date(a.addedOn));
      setAllowlist(sortedData);
      setPagination({ ...pagination, totalItemCount: sortedData.length });
      setAlerts([{message: `${selectedItems.length} domain(s) removed from allowlist successfully!`, statusType: "success"}]);
      setSelectedItems([]);
    } else {
      console.log("REMOVE DOMAINS: RESPONSE ERROR: ", response.error);
      audit("Debug", "Error", "Error removing domain(s) from allowlist", "Allowlist", "DT UI Plugin");
      setAlerts([{message: response.error, statusType: "danger"}])
    }
  };

  const columns = [
    {
      field: 'domainName',
      name: 'Domain Name',
      sortable: true,
      truncateText: true,
      mobileOptions: {
        show: true,
      },
    },
    {
      field: 'addedOn',
      name: 'Added On',
      sortable: true,
      dataType: 'date',
      render: date => formatDate(date, 'shortDateTime'),
      mobileOptions: {
        show: false,
      },
    },
    {
      field: 'addedBy',
      name: 'Added By',
      sortable: true,
      truncateText: true,
      mobileOptions: {
        show: false,
      },
    },
  ];

  const selection = {
    onSelectionChange: onSelectionChange,
  };
  
  const isValid = () => {
    setErrors([]);
    let validationErrors = []

    if(_.isEmpty(domains)) {
      validationErrors.domains = "New domain(s) to add to allowlist is/are blank";
    }
    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  }

  const saveToElastic = async (domains) => {
    let body = "";
    domains.forEach(async domain => {
      body += 
        `{"update":{"_index":"dt-metadata","_id":"${domain.domainName}"}}\r\n{"script":{"source":"ctx._source.allowlisted=params.allowlisted;ctx._source.allowlist_added_on=params.addedOn;ctx._source.allow_added_by=params.addedBy;ctx._source.attribute_type=params.attributeType;ctx._source.attribute_name=params.attributeName","lang":"painless","params": {"allowlisted":true,"addedOn":"${domain.addedOn}","addedBy":"${domain.addedBy}","attributeType":"Domain","attributeName":"${domain.domainName}"}},"upsert":{"allowlisted":true,"allowlist_added_on":"${domain.addedOn}","allowlist_added_by":"${domain.addedBy}","attribute_name":"${domain.domainName}","attribute_type":"Domain"}}\r\n`
    })
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain',
        'kbn-xsrf': 'kibana',
      },
      body: body
    };
    let response = await fetchData(`../api/domaintools/allowlist`, options);
    if(response.ok){
      setAlerts([{message: `${domains.length} saved to allowlist successfully!`, statusType: "success"}])
    } else {
      console.log("SAVE TO ELASTIC: RESPONSE ERROR: ", response);
      audit("Debug", "Error", "Error adding domain(s) to allowlist", "Allowlist", "DT UI Plugin");
      setAlerts([{message: response.error, statusType: "danger"}])
    }
  }
  
  const keyPressedForAdd = async (event) => {
    if (event.key === "Enter") {
      handleAdd();
    }
  }
  
  const keyPressedForSearch = async (event) => {
    if (event.key === "Enter") {
      handleSearch();
    }
  }

  const handleAdd = async () => {
    if (isValid()) {
      setIsLoading(true);
      const trimmedDomains = () => domains.map(domain => domain.trim());
      
      // check for duplicates
      const allowlistAsJustDomains = allowlist.map(domain => domain.domainName);
      const dupDomains = _.intersection(allowlistAsJustDomains, trimmedDomains());
      setDuplicateDomains(dupDomains);
      let newDomains = _.difference(trimmedDomains(), dupDomains);
      
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify({
          securityKey: settings.security_key,
          domains: newDomains,
          serviceUrl: settings.service_url,
        })
      };
      let response = await fetchData(`../api/domaintools/allowlist_validation`, options);
      if(response.ok){
        let goodDomains = [];
        let badDomains = [];
        let extractedDomains = [];
        let originalSubdomains = [];
        response.data.forEach(item => {
          if (item.success) {
            if (item.has_subdomain) {
              extractedDomains.push(item.extracted_domain);
              originalSubdomains.push(item.original_domain);
            } else {
              goodDomains.push(item.extracted_domain);
            }
          } else {
            badDomains.push(item.original_domain);
          }
        });
        setSubdomains(originalSubdomains);

        if (goodDomains.length > 0) {
          const formattedGoodDomains = goodDomains.map(
            domain => ({
              "domainName": domain,
              "addedOn": new Date().toISOString(),
              "addedBy": currentUser
            })
          );
          await saveToElastic(formattedGoodDomains);
          const newAllowlist = _.unionBy(allowlist, formattedGoodDomains, 'domainName');
          const sortedData = newAllowlist.sort((a, b) => new Date(b.addedOn) - new Date(a.addedOn));
          setAllowlist(sortedData);
          setPagination({ ...pagination, totalItemCount: sortedData.length });

          const domainsWithoutGoodDomains = _.difference(newDomains, goodDomains);
          newDomains = domainsWithoutGoodDomains;
        }

        if (badDomains.length > 0){
          let validationErrors = [];
          const badDomainErrorMessages = badDomains.map(domain => `${domain} is not a valid domain name`);
          validationErrors.domains = badDomainErrorMessages;
          setErrors(validationErrors);
        }

        if (extractedDomains.length > 0){
          setExtractedDomainsFromSubdomains(extractedDomains);
          showModal();
        } else if (dupDomains.length > 0) {
          setAlerts([{message: `The following domains already existed in the allowlist: ${dupDomains.join(',')}`, statusType: "warning"}])
        }
        setDomains(newDomains);
      }
      else {
        console.log("HANDLE ADD: RESPONSE ERROR: ", response.error);
        audit("Debug", "Error", "Error validating domain(s) to be allowlisted", "Allowlist", "DT UI Plugin");
        setAlerts([{message: response.error, statusType: "danger"}])
      }

      setIsLoading(false);
    }
  }

  const mergeDomainsFromSubdomainsToAllowlist = async () => {
    const domainsFromSubdomains = extractedDomainsFromSubdomains.map(
      domain => ({
        "domainName": domain,
        "addedOn": new Date().toISOString(),
        "addedBy": currentUser
      })
    );
    await saveToElastic(domainsFromSubdomains);
    const newAllowlist = _.unionBy(allowlist, domainsFromSubdomains, 'domainName');
    const sortedData = newAllowlist.sort((a, b) => new Date(b.addedOn) - new Date(a.addedOn));
    setAllowlist(sortedData);
    setPagination({ ...pagination, totalItemCount: sortedData.length });
    setExtractedDomainsFromSubdomains([]);
    const domainsWithoutSubdomains = _.difference(domains, subdomains);
    setDomains(domainsWithoutSubdomains);
    closeModal();
  }
  
  const closeModal = () => {
    setModalState({ isModalVisible: false });
    setExtractedDomainsFromSubdomains([])
    if (duplicateDomains.length > 0) {
      setAlerts([{message: `The following domains already existed in the allowlist: ${duplicateDomains.join(',')}`, statusType: "warning"}])
    }
  };

  const showModal = () => {
    setModalState({ isModalVisible: true });
  };

  const handleSearch = async (searchContent) => {
    let content = originalAllowlist;
    if(!_.isEmpty(searchContent)) {
      content = originalAllowlist.filter(domain => domain.domainName.includes(searchContent));
    }
    setAllowlist(content);
    setPagination({ ...pagination, totalItemCount: content.length });
  };

  const extractedDomains = extractedDomainsFromSubdomains.map(domain => {
    return <li key={domain}>{domain}</li>;
  })
  
  let modal;
  if (modalState.isModalVisible) {
    modal = (<EuiOverlayMask>
      <EuiConfirmModal
        title="Sub-domain(s) Detected"
        onCancel={closeModal}
        onConfirm={mergeDomainsFromSubdomainsToAllowlist}
        cancelButtonText="No"
        confirmButtonText="Yes"
        defaultFocusedButton="confirm">
      Allowlisting for Sub-domains is not yet supported. Would you like to allowlist the domain(s): <ul>{extractedDomains}</ul>
      </EuiConfirmModal>
    </EuiOverlayMask>);
  }
  
  const sliceStart = (pagination.pageIndex * pagination.pageSize);
  const sliceEnd = (sliceStart + pagination.pageSize);
  const currentItems = allowlist.slice(sliceStart, sliceEnd);

  return (
    <Fragment>
      <Alert alerts={alerts}/>
      <EuiPageContentHeader>
        <EuiFlexGroup justifyContent="spaceBetween">
          <EuiFlexItem>
            <EuiTitle data-id="allowlistTitle">
              <h2>
                <FormattedMessage
                  id="domaintoolsPlugin.allowlistTitle"
                  defaultMessage="Domain Allowlist"/>
              </h2>
            </EuiTitle>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiFieldSearch
              name="searchAllowlist"
              fullWidth
              placeholder="Search..."
              onSearch={handleSearch}
              onChange={e => {handleSearch(e.target.value)}}
              onKeyPress={e => keyPressedForSearch(e)}
              data-id="searchTextInput"
            />
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiSpacer size="xxl" />
        {isLoading ? (
          <EuiText>
            <EuiSpacer size="l" />
            <EuiLoadingSpinner size="xl" />
          </EuiText>
        ) : (
          <Fragment>
            <EuiForm isInvalid={Object.keys(errors).length > 0} error={Object.values(errors)}>
              <EuiFlexGroup>
                <EuiFlexItem>
                  <EuiFormRow
                    fullWidth
                    label={
                      <span>
                        Domain(s) to add to allowlist
                        <span style={{padding: 10 + 'px'}}>
                          <EuiIconTip
                            content={
                              <span>
                                <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                  Currently supports a comma delimited list of values. Domains are required to be in TLD.SLD format "domaintools.com". Maximum of 100 domains can be added a time.
                                </p>
                                <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                  We attempt to weed out subdomains and parse invalid strings. But having a pre-formatted list of valid domains will make the ingestion much easier.
                                </p>
                              </span>
                            }
                            position="right"
                            size="l"
                          />
                        </span>
                      </span>
                    }
                    helpText="comma delimited list"
                    isInvalid={errors.domains !== undefined}>
                    <EuiFieldText
                      name="domains"
                      fullWidth
                      value={domains.join(',')}
                      onChange={e => {
                        setErrors([]);
                        setDomains(e.target.value.split(','));
                      }}
                      onKeyPress={e => keyPressedForAdd(e)}
                      isInvalid={errors.domains !== undefined}
                      data-id="allowlistInput"/>
                  </EuiFormRow>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiFormRow hasEmptyLabelSpace>
                    <EuiButton fill onClick={handleAdd} disabled={isLoading} data-id="allowlistAddButton">
                      Add Domain(s)
                    </EuiButton>
                  </EuiFormRow>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiForm>
            {selectedItems.length > 0 && 
              <EuiButton color="danger" iconType="trash" onClick={removeDomainsFromAllowlist}>
                Remove {selectedItems.length} Allowlisted Domains
              </EuiButton>
            }
            <EuiBasicTable
              items={currentItems}
              itemId="domainName"
              noItemsMessage="No allowlisted domains found"
              columns={columns}
              pagination={pagination}
              sorting={sorting}
              isSelectable={true}
              selection={selection}
              onChange={onTableChange}
            />
          </Fragment>
        )}
      </EuiPageContentBody>
      {modal}
    </Fragment>
  );
}