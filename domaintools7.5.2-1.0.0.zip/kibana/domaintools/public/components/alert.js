import React, { useState, useEffect } from 'react';
import {
  EuiGlobalToastList,
} from '@elastic/eui';
import { v4 as uuidv4 } from 'uuid';

export function Alert(props) {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    function convertMessagesToToasts() {
      const newToasts = props.alerts.map((alert) => {
        const message = (_.isObject(alert.message) ?
          JSON.stringify(alert.message) : alert.message);
        let toast = {
          id: uuidv4(),
          text: <p>{message}</p>,
          color: alert.statusType,
        }
        switch (alert.statusType) {
          case "success":
            toast.title = "Success"
            toast.iconType = "check";
            break;
          case "warning":
            toast.title = "Warning"
            toast.iconType = "help";
            break;
          case "danger":
            toast.title = "Error"
            toast.iconType = "alert";
            toast.toastLifeTimeMs = 30000;
            break
          default:
            toast.title = ""
            toast.iconType = ""
        }
        return toast;
      })
      setToasts([...toasts, ...newToasts]);
    }
    convertMessagesToToasts();
    return () => {};
  }, [props.alerts]);

  const removeToast = removedToast => {
    setToasts(toasts.filter(toast => toast.key !== removedToast.key));
  };

  return (
    <div>
      <EuiGlobalToastList
        toasts={toasts}
        dismissToast={removeToast}
        toastLifeTimeMs={5000}
      />
    </div>
  )
}