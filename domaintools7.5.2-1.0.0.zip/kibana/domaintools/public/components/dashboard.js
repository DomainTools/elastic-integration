import React, { Fragment, useState, useEffect } from 'react';
import {
  EuiFlexGroup,
  EuiFlexItem,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiPanel,
  EuiSuperSelect,
  EuiText,
  EuiTitle,
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';
import { Trends } from './trends';
import { ThreatPortfolio } from './threat_portfolio';
import { ActiveDomains } from './active_domains';
import { NewDomainLookups } from './new_domain_lookups';
import { ActiveTags } from './active_tags';

export function Dashboard() {
  const [settings, setSettings] = useState({});
  const [alerts, setAlerts] = useState([]);
  const [timeframe, setTimeframe] = useState("4h");
  const [allowlist, setAllowlist] = useState([]);
  const [timeframeHelperTextVisible, setTimeframeHelperTextVisible] = useState(false);
  const isMountedRef = useIsMountedRef();

  const options = [
    {
      value: '4h',
      inputDisplay: '4 Hours',
      dropdownDisplay: (
        <Fragment>
          <strong>4 Hours</strong>
        </Fragment>
      ),
    },
    {
      value: '1d',
      inputDisplay: '1 Day',
      dropdownDisplay: (
        <Fragment>
          <strong>1 Day</strong>
        </Fragment>
      ),
    },
    {
      value: '1w',
      inputDisplay: '1 week',
      dropdownDisplay: (
        <Fragment>
          <strong>1 week</strong>
        </Fragment>
      ),
    },
    {
      value: '15d',
      inputDisplay: '15 Days',
      dropdownDisplay: (
        <Fragment>
          <strong>15 Days</strong>
        </Fragment>
      ),
    },
    {
      value: '30d',
      inputDisplay: '30 days',
      dropdownDisplay: (
        <Fragment>
          <strong>30 days</strong>
        </Fragment>
      ),
    },
    {
      value: '60d',
      inputDisplay: '60 days',
      dropdownDisplay: (
        <Fragment>
          <strong>60 days</strong>
        </Fragment>
      ),
    },
  ];

  const timeframeChange = value => {
    setTimeframe(value);
    setTimeframeHelperTextVisible(value === '30d' || value === '60d');
  }

  useEffect(() => {
    async function getSettings() {
      const settingsDocumentId = "1";
      const response = await fetchData(`../api/domaintools/es/dt-settings/${settingsDocumentId}`);
      if (isMountedRef.current) {
        if(response.ok){
          if (response.data._source) {
            setSettings(response.data._source)
          }
        } else {
          audit("Debug", "Entry", "Error getting settings", "Dashboard", "DT UI Plugin");
          setAlerts([{message: response.error, statusType: "danger"}])
        }
      }
    }
    getSettings();
  }, []);

  useEffect(() => {
    async function getAllowlistDomains() {
      const query = {
        "size": 1000,
        "_source": ["attribute_name"],
        "query": {
          "bool": {
            "must": [
              {"term": {"allowlisted": {"value": true}}},
              {"term": {"attribute_type": {"value": "domain"}}}
            ]
          }
        },
        "sort" : [
          { "allowlist_added_on" : {"order" : "desc"}}
        ]
      };
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify(query)
      };
      const domains = await fetchData("../api/domaintools/es/dt-metadata/search", options);
      if (isMountedRef.current){
        if(domains.ok){
          if (domains.data.hits.hits.length > 0) {
            setAllowlist(domains.data.hits.hits.map(domain => domain._source.attribute_name));
          };
        } else {
          audit("Debug", "Error", "Error getting allowlisted domains", "Dashboard", "DT UI Plugin");
          setAlerts([{message: domains.error.msg, statusType: "danger"}])
        }
      }
    }
    getAllowlistDomains();
  }, []);

  return(
    <Fragment>
      <Alert alerts={alerts} />
      <EuiPageContentBody>
        <EuiFlexGroup>
          <EuiFlexItem grow={5}>
            <EuiPageContentHeader>
              <EuiTitle data-id="dashboardTitle">
                <h2>
                  <FormattedMessage
                    id="domaintoolsPlugin.dashboardTitle"
                    defaultMessage="Dashboard"
                  />
                </h2>
              </EuiTitle>
            </EuiPageContentHeader>
          </EuiFlexItem>
          <EuiFlexItem grow={5}>
            {"Timeframe: "}
            <EuiSuperSelect
              options={options}
              valueOfSelected={timeframe}
              onChange={timeframeChange}
              itemLayoutAlign="top"
              hasDividers
              data-id="timeframeSelect"
            />
            {timeframeHelperTextVisible &&
              <EuiText size="s" color="subdued">
                <p className="euiTextColor--subdued">
                  Dashboard refresh time may be impacted based on your environment
                </p>
              </EuiText>
            }
          </EuiFlexItem>
        </EuiFlexGroup>
        <EuiFlexGroup>
          <EuiFlexItem grow={10}>
            <Trends settings={settings} timeframe={timeframe} allowlist={allowlist}/>
          </EuiFlexItem>
        </EuiFlexGroup>
        <EuiFlexGroup>
          <EuiFlexItem grow={5}>
            <EuiPanel paddingSize="l" hasShadow grow={false}>
              <ThreatPortfolio settings={settings} timeframe={timeframe}/>
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem grow={5}>
            <EuiPanel paddingSize="l" hasShadow grow={false}>
              <ActiveDomains settings={settings} timeframe={timeframe}/>
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>
        <EuiFlexGroup>
          <EuiFlexItem grow={true}>
            <EuiPanel paddingSize="l" hasShadow grow={false}>
              <NewDomainLookups />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem grow={true}>
            <EuiPanel paddingSize="l" hasShadow grow={false}>
              <ActiveTags settings={settings} timeframe={timeframe}/>
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPageContentBody>
    </Fragment>
  )
}