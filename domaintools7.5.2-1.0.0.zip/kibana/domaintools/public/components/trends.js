import React, { Fragment } from 'react';
import {
  EuiFlexGroup,
  EuiFlexItem
} from '@elastic/eui';
import { DangerousDomains } from './dangerous_domains';
import { SuspicousDomains } from './suspicious_domains';
import { YoungDomains } from './young_domains';
import { EventsEnriched } from './events_enriched';

export function Trends(props) {
  return(
    <Fragment>
      <EuiFlexGroup guttersize="l">
        <EuiFlexItem>
          <DangerousDomains settings={props.settings} timeframe={props.timeframe} allowlist={props.allowlist} />
        </EuiFlexItem>
        <EuiFlexItem>
          <SuspicousDomains settings={props.settings} timeframe={props.timeframe} allowlist={props.allowlist}/>
        </EuiFlexItem>
        <EuiFlexItem>
          <YoungDomains settings={props.settings} timeframe={props.timeframe}/>
        </EuiFlexItem>
        <EuiFlexItem>
          <EventsEnriched settings={props.settings} timeframe={props.timeframe} />
        </EuiFlexItem>
      </EuiFlexGroup>
    </Fragment>
  )
}