import React, { Fragment, useEffect, useState } from 'react';
import {
  EuiButton,
  EuiConfirmModal,
  EuiEmptyPrompt,
  EuiFieldSearch,
  EuiFlexGrid,
  EuiFlexGroup,
  EuiFlexItem,
  EuiForm,
  EuiFormRow,
  EuiIconTip,
  EuiLoadingSpinner,
  EuiOverlayMask,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiPanel,
  EuiSpacer,
  EuiTitle,
  EuiToolTip,
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { CardPanel } from './card_panel';
import { FieldValueTable } from './field_value_table';
import { AdditionalEmailTable } from './additional_email_table';
import { MailServerTable } from './mail_server_table';
import { NameServerTable } from './name_server_table';
import { IPAddressTable } from './ip_address_table';
import { IrisTagsTable } from './iris_tags_table';
import { SPFInfoTable } from './spf_info_table';
import { SSLInfoTable } from './ssl_info_table';
import { RelatedEvents } from './related_events';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';


export function DomainProfile(props) {
  const [modalState, setModalState] = useState({
    isModalVisible: false,
  });
  const [missingCreds, setMissingCreds] = useState(true);
  const [isComponentLoading, setIsComponentLoading] = useState(true);
  const [isSearchLoading, setIsSearchLoading] = useState(false);
  const [hasData, setHasData] = useState(false);
  const [firstCheck, setFirstCheck] = useState(true);
  const [errors, setErrors] = useState([]);
  const [extractedDomain, setExtractedDomain] = useState('');
  const [settings, setSettings] = useState({});
  const [alerts, setAlerts] = useState([]);
  const [form, setState] = useState({
    searchDomain: '',
    indices: '',
    returnData: {
      'domain_panel': { 'risk_score_color': 'green', 'risk_score': '0', 'domain_name': '' },
      'domain_age': '',
      'domain_status': { 'text': '', 'color': '' },
      'threat_profile_evidence': '',
      'threat_profile_type': '',
      'malware_score': '0',
      'spam_score': '0',
      'phishing_score': '0',
      'proximity_score': '0',
      'registry_table': [],
      'contextual_table': [],
      'mail_server_table': [],
      'name_server_table': [],
      'ssl_info_table': [],
      'ip_address_table': [],
      'iris_tag_table': [],
      'admin_contact_table': [],
      'technical_contact_table': [],
      'billing_contact_table': [],
      'spf_info_table': [],
      'email_address_table': [],
    },
    relatedEvents: [],
  });
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getSettings() {
      const settingsDocumentId = "1";
      const response = await fetchData(`../api/domaintools/es/dt-settings/${settingsDocumentId}`);
      if (isMountedRef.current){
        if (response.ok) {
          if (response.data._source) {
            const source = response.data._source;
            if (source.api_user !== '' && source.api_key !== '') {
              let log_indices = source.log_indices;
              if (typeof log_indices === 'undefined') {
                log_indices = '*';
              }
              else {
                log_indices = log_indices.join(',');
              }
              source.log_indices = log_indices;
              setSettings(source);
              setMissingCreds(false);
            }

          }
        } else {
          audit("Debug", "Entry", "Error getting settings", "Domain Profile", "DT UI Plugin");
          setAlerts([{ message: response.error, statusType: 'danger' }]);
        }
        setIsComponentLoading(false);
      }
    }

    getSettings();
  }, []);

  const closeModal = () => {
    setModalState({ isModalVisible: false });
    setFirstCheck(true);
    setExtractedDomain('');
  };

  const showModal = () => {
    setModalState({ isModalVisible: true });
  };

  const searchRelatedEvents = async () => {
    const query = {
      'size': 100,
      'query': {
        'bool': {
          'filter': {
            'bool': {
              'must': [
                {
                  'term': {
                    'domaintools.domain_name.keyword': `${extractedDomain}`,
                  },
                },
                {
                  'range': {
                    '@timestamp': {
                      'gte': `now-7d/d`,
                    },
                  },
                },
              ],
            },
          },
        },
      },
      'sort': [{ '@timestamp': 'desc' }],
    };

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
      },
      body: JSON.stringify(query),
    };

    const response = await fetchData(`../api/domaintools/es/${settings.log_indices}/search`, options);
    if (response.ok) {
      let tmpArray = [];
      for (const key in response.data.hits.hits) {
        let value = response.data.hits.hits[key];
        tmpArray.push({
          timestamp: _.get(value, '_source[\'@timestamp\']', ''),
          index: _.get(value, '_index', ''),
          event_id: _.get(value, '_id', ''),
          client_ip: _.get(value, '_source.client.ip', ''),
          destination_ip: _.get(value, '_source.destination.ip', ''),
          url_domain: _.get(value, '_source.url.domain', ''),
        });
      }
      return tmpArray;
    } else {
      let errorMessage = response.error;
      if (errorMessage.response) {
        const error = JSON.parse(errorMessage.response);
        errorMessage = error && error.error && error.error.reason || 'Unknown Error';
      }
      audit("Debug", "Entry", "Error getting settings", "Lookup", "DT UI Plugin");
      setAlerts([{ message: errorMessage, statusType: 'danger' }]);
    }
  };

  const handleSearch = async () => {
    setHasData(false);
    setIsSearchLoading(true);
    setErrors([]);
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
      },
      body: JSON.stringify({
        search_domain: form.searchDomain,
        first_check: firstCheck,
        securityKey: settings.security_key,
        serviceUrl: settings.service_url,
      }),
    };
    let response = await fetchData(`../api/domaintools/adhoc_domain_profile`, options);
    if (response.data.has_subdomain) {
      setFirstCheck(false);
      setExtractedDomain(response.data.extracted_domain);
      showModal();
    } else if (response.data.no_result) {
      setErrors(['We are unable to understand the entered Domain.\n\nPlease ensure the entered domain is in TLD.SLD format for a successful lookup.'])
    } else if (response.data.result) {
      let relatedEvents = await searchRelatedEvents();
      setState({
        returnData: response.data.result,
        relatedEvents: relatedEvents,
        searchDomain: extractedDomain,
        indices: form.indices,
      });
      closeModal();
      setHasData(true);
    } else {
      console.log(`RESPONSE ERROR: ${JSON.stringify(response.error)}`);
      audit("Debug", "Entry", "Error doing lookup", "Lookup", "DT UI Plugin");
      setAlerts([{ message: response.error, statusType: 'danger' }]);
    }
    setIsSearchLoading(false);
  };

  let modal;
  if (modalState.isModalVisible) {
    modal = (<EuiOverlayMask>
      <EuiConfirmModal
        title="Sub-domain Detected"
        onCancel={closeModal}
        onConfirm={handleSearch}
        cancelButtonText="No"
        confirmButtonText="Yes"
        defaultFocusedButton="confirm">
        <p>Lookup for Sub-domains are not yet supported. Would you like to lookup the
          domain <b>{extractedDomain}</b> instead?</p>
      </EuiConfirmModal>
    </EuiOverlayMask>);
  }

  const makeApiSettingsVisible = () => {
    props.makeApiSettingsVisible();
  }

  const threatProfileScoreTextColor = (score) => {
    if (score >= settings.threat_profile_score_threshold){
      return 'red';
    }
    return 'green';
  }
  
  const proximityScoreTextColor = (score) => {
    if (score >= settings.proximity_score_threshold){
      return 'red';
    }
    return 'green';
  }

  return (
    <Fragment>
      {isComponentLoading ? (
        <EuiFlexGroup justifyContent="spaceAround">
          <EuiFlexItem grow={false}>
            <EuiSpacer size="l" />
            <EuiLoadingSpinner size="xl" />
          </EuiFlexItem>
        </EuiFlexGroup>
      ) : (
        <Fragment>
          {missingCreds ? (
            <EuiEmptyPrompt
              iconType="alert"
              iconColor="danger"
              title={<h2>App not setup completely</h2>}
              body={
                <Fragment>
                  <p>We are unable to validate your DomainTools API Key</p>
                  <p>
                    If you continue to receive this error,<br/>
                    please reach out to DomainTools support.
                  </p>
                </Fragment>
              }
              actions={
                <EuiButton color="primary" fill onClick={makeApiSettingsVisible}>
                  Validate Setup Steps
                </EuiButton>
              }
            />
          ) : (
            <Fragment>
              <Alert alerts={alerts}/>
              <EuiPageContentHeader>
                <EuiTitle data-id="domainProfileTitle">
                  <h2>
                    <FormattedMessage
                      id="domaintoolsPlugin.domainProfileTitle"
                      defaultMessage="Domain Profile"/>
                  </h2>
                </EuiTitle>
              </EuiPageContentHeader>
              <EuiPageContentBody>
                <EuiPanel paddingSize="l" hasShadow>
                  <EuiForm isInvalid={errors.length > 0} error={errors}>
                    <EuiFlexGroup style={{ maxWidth: 600 }}>
                      <EuiFlexItem>
                        <EuiFormRow label="Lookup a domain with the Iris Investigate API" isInvalid={errors.length > 0}>
                          <EuiFieldSearch
                            name="searchDomain"
                            value={form.searchDomain}
                            onSearch={handleSearch}
                            onChange={e => {
                              setErrors([]);
                              setState({ ...form, [e.target.name]: e.target.value });
                            }}
                            isInvalid={errors.length > 0}
                            data-id="searchTextInput"
                          />
                        </EuiFormRow>
                      </EuiFlexItem>
                      <EuiFlexItem>
                        <EuiFormRow hasEmptyLabelSpace>
                          <EuiButton data-id="searchBtn" fill onClick={handleSearch}>
                            Search
                          </EuiButton>
                        </EuiFormRow>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiForm>
                </EuiPanel>
                {isSearchLoading &&
                  <EuiFlexGroup justifyContent="spaceAround">
                    <EuiFlexItem grow={false}>
                      <EuiSpacer size="l" />
                      <EuiLoadingSpinner size="xl" />
                    </EuiFlexItem>
                  </EuiFlexGroup>
                }
                {hasData &&
                <div>
                  <EuiFlexGrid columns={2}>
                    <EuiFlexItem grow={6} style={{ minWidth: '60%' }}>
                      <EuiPanel className="euiFlexGroup--alignItemsCenter" style={{ display: 'flex' }} hasShadow>
                        <EuiToolTip 
                          content="DomainTools Overall Risk Score"
                          position="top"
                          size="l"
                        >
                          <div style={{
                            height: '100px',
                            width: '100px',
                            backgroundColor: form.returnData.domain_panel.risk_score_color,
                            marginRight: '1rem',
                            fontSize: '50px',
                            color: 'white',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}>
                              {form.returnData.domain_panel.risk_score}
                          </div>
                        </EuiToolTip>
                        <EuiTitle data-id="domainPanelDomainName" size="l"><h1
                          style={{
                            fontSize: '75px',
                            color: '#2094f3',
                            textOverflow: 'ellipsis',
                            overflow: 'hidden',
                            lineHeight: 1.25
                          }}>{form.returnData.domain_panel.domain_name}</h1>
                        </EuiTitle>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ maxWidth: '35%' }}>
                      <EuiSpacer size="l"/>
                        <span style={{display: 'inline'}}>
                          <a style={{ textAlign: 'center' }} href={form.returnData.domain_panel.iris_url} target="_blank" rel="noopener noreferrer">DomainTools Iris
                            Investigate Link</a>
                          <EuiIconTip 
                            content="Research this IOC in DomainTools Iris Investigate platform"
                            position="right"
                            size="l"
                          />
                        </span>
                      <EuiSpacer/>
                      <EuiFlexGrid columns={2}>
                        <EuiFlexItem>
                          <EuiPanel paddingSize="s" hasShadow>
                            <CardPanel title="Age (Days)" value={form.returnData.domain_age}/>
                          </EuiPanel>
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiPanel paddingSize="s" hasShadow>
                            <CardPanel title="Domain Status" value={form.returnData.domain_status.text}
                                      text_color={form.returnData.domain_status.color}/>
                          </EuiPanel>
                        </EuiFlexItem>
                      </EuiFlexGrid>
                    </EuiFlexItem>
                  </EuiFlexGrid>
                  <EuiFlexGroup>
                    <EuiFlexItem grow={false}>
                      <EuiPanel paddingSize="l" hasShadow>
                        <CardPanel title="Threat Profile Threats" value={form.returnData.threat_profile_type || '--'}
                                  text_color="#2094f3"/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '10%' }}>
                      <EuiPanel paddingSize="l" hasShadow>
                        <CardPanel title="Phishing Score" value={form.returnData.phishing_score}
                                  text_color={threatProfileScoreTextColor(form.returnData.phishing_score)}/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '10%' }}>
                      <EuiPanel paddingSize="l" hasShadow>
                        <CardPanel title="Malware Score" value={form.returnData.malware_score}
                                  text_color={threatProfileScoreTextColor(form.returnData.malware_score)}/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '10%' }}>
                      <EuiPanel paddingSize="l" hasShadow>
                        <CardPanel title="Spam Score" value={form.returnData.spam_score}
                                  text_color={threatProfileScoreTextColor(form.returnData.spam_score)}/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '10%' }}>
                      <EuiPanel paddingSize="l" hasShadow>
                        <CardPanel title="Proximity Score" value={form.returnData.proximity_score}
                                  text_color={proximityScoreTextColor(form.returnData.proximity_score)}/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiFlexGroup>
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <CardPanel title="Threat Profile Evidence" value={form.returnData.threat_profile_evidence || '--'}
                                  text_color="#2094f3"/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiFlexGrid columns={2} direction="row">
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <FieldValueTable title="Contextual" items={form.returnData.contextual_table}
                                        pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <AdditionalEmailTable title="Email Addresses" items={form.returnData.email_address_table}
                                              pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGrid>
                  <EuiFlexGrid columns={1} direction="column">
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <IrisTagsTable title="Iris Tags" items={form.returnData.iris_tag_table}/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGrid>
                  <EuiPanel paddingSize="l" hasShadow>
                    <EuiPageContentHeader>
                      <EuiTitle>
                        <h2>
                          <FormattedMessage
                            id="domaintoolsPlugin.domainProfileConnectedInfrastructureTitle"
                            defaultMessage="Connected Infrastructure"/>
                        </h2>
                      </EuiTitle>
                    </EuiPageContentHeader>
                    <EuiFlexGrid columns={2} direction="column">
                      <EuiFlexItem>
                        <EuiPanel paddingSize="l" hasShadow>
                          <MailServerTable title="Mail Servers" items={form.returnData.mail_server_table}
                                          pivotThreshold={settings.pivot_threshold}/>
                        </EuiPanel>
                      </EuiFlexItem>
                      <EuiFlexItem>
                        <EuiPanel paddingSize="l" hasShadow>
                          <SPFInfoTable title="SPF Info" items={form.returnData.spf_info_table}/>
                        </EuiPanel>
                      </EuiFlexItem>
                      <EuiFlexItem>
                        <EuiPanel paddingSize="l" hasShadow>
                          <IPAddressTable title="IP Addresses" items={form.returnData.ip_address_table}
                                          pivotThreshold={settings.pivot_threshold}/>
                        </EuiPanel>
                      </EuiFlexItem>
                      <EuiFlexItem>
                        <EuiPanel paddingSize="l" hasShadow>
                          <NameServerTable title="Name Servers" items={form.returnData.name_server_table}
                                          pivotThreshold={settings.pivot_threshold}/>
                        </EuiPanel>
                      </EuiFlexItem>
                    </EuiFlexGrid>
                  </EuiPanel>
                  <EuiFlexGrid columns={1} direction="column">
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <SSLInfoTable title="SSL Info" items={form.returnData.ssl_info_table}
                                      pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGrid>
                  <EuiFlexGrid columns={1}>
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <FieldValueTable title="Registrar Information" items={form.returnData.registry_table}
                                        pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGrid>
                  <EuiFlexGrid columns={4}>
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <FieldValueTable title="Admin Contact Information" items={form.returnData.admin_contact_table}
                                        pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <FieldValueTable title="Technical Contact Information" items={form.returnData.technical_contact_table}
                                        pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <FieldValueTable title="Billing Contact Information" items={form.returnData.billing_contact_table}
                                        pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <FieldValueTable title="Registrant Contact Information" items={form.returnData.registrant_contact_table}
                                        pivotThreshold={settings.pivot_threshold}/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGrid>
                  <EuiFlexGrid columns={1} direction="column">
                    <EuiFlexItem>
                      <EuiPanel paddingSize="l" hasShadow>
                        <RelatedEvents items={form.relatedEvents} domain={form.searchDomain}
                                      indices={settings.log_indices}/>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGrid>
                </div>}
              </EuiPageContentBody>
              {modal}
            </Fragment>
          )}
        </Fragment>
      )}
    </Fragment>
  );
}
