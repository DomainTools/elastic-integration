import React, { useEffect, useState } from 'react';
import {
  EuiBasicTable,
  EuiIconTip,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiSelect,
  EuiTitle
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { audit, fetchData } from '../helpers';
import {Alert} from "./alert";


export function RelatedEvents(props) {
  const [alerts, setAlerts] = useState([]);
  const [form, setState] = useState({searchTime: '7', searchDomain: props.domain, indices: props.indices, items: props.items});

  useEffect(() => {
    async function getSettings() {
      setState({searchTime: '7', searchDomain: props.domain, indices: props.indices, items: props.items})
    }
    getSettings();
    return () => {};
  }, [props]);

  const searchRelatedEvents = async (params) => {
    const query = {
      "size": 100,
      'query': {
        'bool': {
          'filter': {
            'bool': {
              'must': [
                {
                  'term': {
                    'domaintools.domain_name.keyword': `${params.search_domain}`,
                  },
                },
                {
                  'range': {
                    '@timestamp': {
                      'gte': `now-${params.search_time}d/d`,
                    },
                  },
                },
              ],
            },
          },
        },
      },
      "sort": [{ "@timestamp" : "desc" }]
    };
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
      },
      body: JSON.stringify(query)
    };
    const response = await fetchData(`../api/domaintools/es/${params.indices}/search`, options);
    if (response.ok) {
      let tmpArray = [];
      for (const key in response.data.hits.hits) {
        let value = response.data.hits.hits[key];
        tmpArray.push({ timestamp: _.get(value, "_source['@timestamp']", ""), index: _.get(value, "_index", ""), event_id: _.get(value, "_id", ""), client_ip: _.get(value, "_source.client.ip", ""), destination_ip: _.get(value, "_source.destination.ip", ""), url_domain: _.get(value, "_source.url.domain", "") });
      }
      return tmpArray;
    } else {
      let errorMessage = response.error;
      if (errorMessage.response) {
        const error = JSON.parse(errorMessage.response);
        errorMessage = error && error.error && error.error.reason || "Unknown Error";
      }
      audit("Debug", "Error", "Error getting related domains", "Lookup", "DT UI Plugin");
      setAlerts([{ message: errorMessage, statusType: 'danger' }]);
    }
  };

  const onSelectChange = async (event) => {
    let params = { search_domain: form.searchDomain, indices: form.indices, search_time: event };
    let itemData = await searchRelatedEvents(params);
    setState({ searchTime: event, searchDomain: form.searchDomain, indices: form.indices, items: itemData });
  };
  
  const columns = [
    {
      field: 'timestamp',
      name: 'Timestamp',
    },
        {
      field: 'client_ip',
      name: 'Client IP',
    },
        {
      field: 'destination_ip',
      name: 'Destination IP',
    },
    {
      field: 'url_domain',
      name: 'URL Domain',
    },
    {
      field: 'index',
      name: 'Index',
    },
    {
      field: 'event_id',
      name: 'Event ID',
    },
  ];

  const options = [
    { value: '7', text: '1 Week' },
    { value: '14', text: '2 Weeks' },
    { value: '21', text: '3 Weeks' },
    { value: '28', text: '4 Weeks' },
  ];

  return (
    <div>
      <Alert alerts={alerts} />
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.relatedEventsTitle"
              defaultMessage="Related Events"/>
            <span style={{padding: 10 + 'px'}}>
              <EuiIconTip 
                content="Up to 100 recent events are retrieved from the index pattern supplied during App configuration. You may manually expand your search to other indexes and timeframe using Discover Tab"
                position="right"
                size="l"
              />
            </span>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiSelect
          id="selectTime"
          options={options}
          onChange={e => onSelectChange(e.target.value)}
          value={form.searchTime}
        />
        <EuiBasicTable
          items={form.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
