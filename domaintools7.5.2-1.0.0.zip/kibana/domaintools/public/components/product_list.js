import React from 'react';
import '../style/product_list.css'

export function ProductList(productsList) {
    return(
      <div className="ProductList">
        <h4>Avaliable Iris Products</h4>
        {productsList.map((product) =>
            <ProductListItem key={ product['id'] } value={ product } />
        )}
      </div>
    );
  }

function ProductListItem(props) {
    const { id, endpoint } = props.value;
    return(
        <div className="ProductList_item">
            <h6>{ id }</h6>
            <div className="ProductList_item_contents">
                <i>Endpoint:</i><br/>
                { endpoint }
            </div>
        </div>
    );
  }