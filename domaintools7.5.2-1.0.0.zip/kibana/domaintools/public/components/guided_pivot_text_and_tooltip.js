import React from 'react';
import { EuiIconTip } from '@elastic/eui';
import domaintoolsSvg from '../images/domaintools.svg';

export function GuidedPivotTextAndTooltip(props) {
        let color, tooltip;
        if (props.count && props.count < props.pivotThreshold) {
          color = '#2094f3';
        } else {
          color = '#000000'
        }
        if (props.count) {
          tooltip = <EuiIconTip 
            title="Number of Related Domains"
            content={props.count}
            position="right"
            size="m"
            type={domaintoolsSvg}
          />
        }
        return (
          <span>
            <span style={{ color: color }}>
              {props.text}{' '}
              </span>{tooltip}</span>
        );
}