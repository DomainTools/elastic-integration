import { Selector } from 'testcafe';

const config = require('./config.json');

fixture `Login`

test('Confirm login prompt', async t => {
  await t
    .navigateTo(`${config.baseUrl}`)
    .expect(Selector('input').withAttribute('name', 'username').exists).ok()
    .expect(Selector('input').withAttribute('name', 'password').exists).ok();
});