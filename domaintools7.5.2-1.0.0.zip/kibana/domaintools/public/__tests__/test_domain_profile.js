import { Selector } from 'testcafe';
import { user } from './helpers';
import {
  domainProfileLink,
  domainProfileTitle,
  domainProfileSearchInput,
  domainProfileSearchBtn,
  domainProfilePanelDomainName,
  domainProfileModalCancelBtn,
  domainProfileModalConfirmBtn,
  domainProfileErrorForm,
} from './selectors';

const config = require('./config.json');

fixture`DomainProfile`
  .page(`${config.baseUrl}app/domaintools`)
  .beforeEach(async (t) => {
    await t.useRole(user)
      .click(domainProfileLink);
  });

test('Valid Domain', async (t) => {
  await t
    .expect(Selector(domainProfileTitle).innerText).eql('Domain Profile')
    .typeText(domainProfileSearchInput, 'int-chase.com')
    .click(domainProfileSearchBtn)
    .expect(Selector(domainProfilePanelDomainName).innerText)
    .eql('int-chase.com');
});

test('Valid SubDomain and Get Data', async (t) => {
  await t
    .expect(Selector(domainProfileTitle).innerText).eql('Domain Profile')
    .typeText(domainProfileSearchInput, 'use.expensify.com')
    .click(domainProfileSearchBtn)
    .click(domainProfileModalConfirmBtn)
    .expect(Selector(domainProfilePanelDomainName).innerText)
    .eql('expensify.com');
});

test('Valid SubDomain and Dont Get Data', async (t) => {
  await t
    .expect(Selector(domainProfileTitle).innerText).eql('Domain Profile')
    .typeText(domainProfileSearchInput, 'use.expensify.com')
    .click(domainProfileSearchBtn)
    .click(domainProfileModalCancelBtn)
    .expect(Selector(domainProfilePanelDomainName).exists)
    .notOk();
});

test('Invalid Domain', async (t) => {
  await t
    .expect(Selector(domainProfileTitle).innerText).eql('Domain Profile')
    .typeText(domainProfileSearchInput, 'test')
    .click(domainProfileSearchBtn)
    .expect(Selector(domainProfilePanelDomainName).exists)
    .notOk()
    .expect(Selector(domainProfileErrorForm).innerText)
    .contains('We are unable to understand the entered Domain.');
});

test('Valid Domain No DT Data', async (t) => {
  await t
    .expect(Selector(domainProfileTitle).innerText).eql('Domain Profile')
    .typeText(domainProfileSearchInput, 'aaanotareallydomain.com')
    .click(domainProfileSearchBtn)
    .expect(Selector(domainProfilePanelDomainName).exists)
    .notOk()
    .expect(Selector(domainProfileErrorForm).innerText)
    .contains('We are unable to understand the entered Domain.');
});
