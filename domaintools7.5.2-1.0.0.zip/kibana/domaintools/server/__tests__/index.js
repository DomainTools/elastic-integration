import expect from '@kbn/expect';

// Run this test with `yarn test:server`
describe('suite', () => {
  it('is a test', () => {
    expect(true).to.equal(true);
  });
});
