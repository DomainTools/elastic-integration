import React from 'react';
import { EuiBasicTable, EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { GuidedPivotTextAndTooltip } from './guided_pivot_text_and_tooltip'

export function AdditionalEmailTable(props) {
  const columns = [
    {
      field: 'label',
      name: 'Type',
    },
    {
      field: 'email',
      name: 'Email',
      render: (email, item) => {
        return <GuidedPivotTextAndTooltip count={item.count} text={email} pivotThreshold={props.pivotThreshold} />
      },
    },
  ];

  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.additionalEmailTableTitle"
              defaultMessage={props.title}/>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiBasicTable
          items={props.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
