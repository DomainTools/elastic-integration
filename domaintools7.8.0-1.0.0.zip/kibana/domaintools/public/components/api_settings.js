import React, { useState, useEffect, Fragment } from 'react';
import {
  EuiButton,
  EuiCallOut,
  EuiCheckbox,
  EuiFieldPassword,
  EuiFieldText,
  EuiFlexGroup,
  EuiFlexItem,
  EuiForm,
  EuiFormRow,
  EuiIconTip,
  EuiLoadingSpinner,
  EuiPanel,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiSpacer,
  EuiTitle,
  EuiText
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { ProductList } from './product_list';
import { Alert } from './alert';
import { Token, Secret } from 'fernet';

export function ApiSettings() {
  const [output, setOutput] = useState(<div />);
  const [isLoading, setIsLoading] = useState(false);
  const [alerts, setAlerts] = useState([]);
  const [form, setState] = useState({
    documentId: null,
    securityKey: "",
    username: "",
    apiKey: "",
    enableProxyChecked: false,
    proxyServer: "",
    proxyPort: "",
    customCertificateChecked: false,
    customCertificatePath: "",
    serviceUrl: "http://localhost:8000"
  })
  const [previousState, setPreviousState] = useState(form);
  const [errors, setErrors] = useState([]);
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getSettings() {
      setIsLoading(true)
      const settingsDocumentId = "1";
      const response = await fetchData(`../api/domaintools/es/dt-settings/${settingsDocumentId}`);
      if (isMountedRef.current){
        if(response.ok){
          if (response.data._source) {
            const source = response.data._source;
            let decryptedApiKey = ''
            if(source.api_key) {
              const secret = new Secret(source.security_key)
              const token = new Token({
                secret: secret,
                token: source.api_key,
                ttl: 0
              });
              decryptedApiKey = token.decode()
            }
            const elasticData = {
              documentId: settingsDocumentId,
              securityKey: source.security_key,
              username: source.api_user,
              apiKey: decryptedApiKey,
              enableProxyChecked: source.enable_proxy,
              proxyServer: source.proxy_server,
              proxyPort: source.proxy_port,
              customCertificateChecked: source.custom_certificate,
              customCertificatePath: source.custom_certificate_path,
              serviceUrl: source.service_url
            };
            setState(elasticData);
            setPreviousState(elasticData);
          }
        } else {
          audit("Debug", "Error", "Error getting settings", "AppConfig", "DT UI Plugin");
          setAlerts([{message: response.error.msg, statusType: "danger"}])
        }
        setIsLoading(false)
      }
    }
    getSettings();
  }, []);

  const isValid = () => {
    setErrors({});
    let validationErrors = {}
    if(!form.username) {
      validationErrors.username = "Username is blank";
    }

    if(!form.apiKey){
      validationErrors.apiKey = "API key is blank";
    }

    if(form.enableProxyChecked){
      if(!form.proxyServer) {
        validationErrors.proxyServer = "Proxy server is blank";
      }

      const oneOrMoreNumbersPattern = /^\d+$/
      const result = form.proxyPort.match(oneOrMoreNumbersPattern)
      if(!result) {
        validationErrors.proxyPort = "Proxy port can only be numbers";
      }
    }

    if(form.customCertificateChecked){
      if(!form.customCertificatePath) {
        validationErrors.customCertificatePath = "SSL Custom Certificate Path is blank";
      }
    }
    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  }

  const keyPressed = async (event) => {
    if (event.key === "Enter") {
      testConnection();
    }
  }

  const testConnection = async () => {
    if (isValid()) {
      setIsLoading(true);
      setOutput(<div />);
      let encryptedApiKey = encryptApiKey();
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify({
          securityKey: form.securityKey,
          username: form.username,
          apiKey: encryptedApiKey,
          enableProxy: form.enableProxyChecked,
          proxyServer: form.proxyServer,
          proxyPort: form.proxyPort,
          customCertificate: form.customCertificateChecked,
          customCertificatePath: form.customCertificatePath,
          serviceUrl: form.serviceUrl
        })
      };
      let response = await fetchData(`../api/domaintools/test_connection`, options);
      if(response.ok){
        if (response.data.length > 0){
          setOutput(ProductList(response.data));
        }
      }
      else {
        let errorMessage = response.error;
        if(response.error.code) {
          if(response.error.code === 'ECONNRESET'){
            errorMessage = "Connection timed out.";
            if(form.proxyServer){
              errorMessage += " Please verify your proxy information";
            }
          }
          if(response.error.code === "ECONNREFUSED") {
            errorMessage = "Unable to connect to background service.  Please check its status."
          }
        }
        audit("Debug", "Error", "Error testing API connection", "AppConfig", "DT UI Plugin");
        setAlerts([{message: errorMessage, statusType: "danger"}])
      }
      setIsLoading(false);
    }
  }

  const encryptApiKey = () => {
    let encryptedApiKey = '';
    if(form.apiKey) {
      const secret = new Secret(form.securityKey);
      const token = new Token({
        secret: secret,
        ttl: 0
      });
      encryptedApiKey = token.encode(form.apiKey);
    }
    return encryptedApiKey;
  }

  const refreshServiceSettings = async () => {
    if (isValid()) {
      setIsLoading(true);
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify({
          securityKey: form.securityKey,
          serviceUrl: form.serviceUrl
        }),
      };
      let response = await fetchData(`../api/domaintools/refresh_settings`, options);
      if (response.ok) {
        if (response.data.length > 0) {
          setAlerts([{ message: response.data, statusType: 'success' }]);
        }
      } else {
        audit("Debug", "Error", "Error refreshing API settings", "AppConfig", "DT UI Plugin");
        setAlerts([{ message: response.error, statusType: 'danger' }]);
      }
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setOutput('');
    if (isValid()) {
      setIsLoading(true);
      let encryptedApiKey = encryptApiKey();
      const options = {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify({"doc": {
          security_key: form.securityKey,
          api_user: form.username,
          api_key: encryptedApiKey,
          enable_proxy: form.enableProxyChecked,
          proxy_server: form.proxyServer,
          proxy_port: form.proxyPort,
          custom_certificate: form.customCertificateChecked,
          custom_certificate_path: form.customCertificatePath
        }})
      };
      let response = await fetchData(`../api/domaintools/update/es/dt-settings/${form.documentId}`, options);
      if(response.ok){
        setAlerts([{message: "Save Successful!", statusType: "success"}])
        await refreshServiceSettings();
      }
      else {
        audit("Debug", "Error", "Error saving API settings", "AppConfig", "DT UI Plugin");
        setAlerts([{message: response.error, statusType: "danger"}])
      }
      setPreviousState(form);
      setIsLoading(false);
    }
  }

  return (
    <div>
      <EuiPageContentBody>
        <Alert alerts={alerts} />
        <Fragment>
          <EuiForm isInvalid={Object.keys(errors).length > 0} error={Object.values(errors)}>
            <EuiPanel paddingSize="l" hasShadow>
              <EuiPageContentHeader>
                <EuiTitle>
                  <h2>
                    <FormattedMessage
                      id="domaintoolsPlugin.apiCredentialsTitle"
                      defaultMessage="API Credentials"
                    />
                    <span style={{padding: 10 + 'px'}}>
                      <EuiIconTip
                        content={
                          <span>
                            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                              Active DomainTools credentials for Elastic are required for the app to operate.
                            </p>
                            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                              Please reach out to DomainTools support if you need assistance.
                            </p>
                          </span>
                        }
                        position="right"
                        size="l"
                      />
                    </span>
                  </h2>
                </EuiTitle>
              </EuiPageContentHeader>
              <EuiFormRow label="Username" isInvalid={errors.username !== undefined}>
                <EuiFieldText
                  name="username"
                  value={form.username}
                  onChange={e => {
                    let newErrors = errors;
                    delete newErrors.username;
                    setErrors(newErrors);
                    setState({...form, [e.target.name]: e.target.value});
                  }}
                  onKeyPress={e => keyPressed(e)}
                  isInvalid={errors.username !== undefined} />
              </EuiFormRow>
              <EuiFormRow label="API Key" isInvalid={errors.apiKey !== undefined}>
                <EuiFieldPassword
                  name="apiKey"
                  value={form.apiKey}
                  onChange={e => {
                    let newErrors = errors;
                    delete newErrors.apiKey;
                    setErrors(newErrors);
                    setState({...form, [e.target.name]: e.target.value});
                  }}
                  onKeyPress={e => keyPressed(e)}
                  isInvalid={errors.apiKey !== undefined} />
              </EuiFormRow>
            </EuiPanel>
            <EuiSpacer />
            <EuiPanel paddingSize="l" hasShadow>
              <EuiPageContentHeader>
                <EuiTitle>
                  <h2>
                    <FormattedMessage
                      id="domaintoolsPlugin.proxyTitle"
                      defaultMessage="Proxy"
                    />
                  </h2>
                </EuiTitle>
              </EuiPageContentHeader>
              <EuiFormRow>
                <EuiCheckbox
                  id="enableProxyChecked"
                  name="enableProxyChecked"
                  label={
                    <span>
                      Enable Proxy
                      <span style={{padding: 10 + 'px'}}>
                        <EuiIconTip
                          content={
                            <span>
                              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                If 'Enable Proxy' is checked, Proxy Server and Port must be provided for a successful connection.
                              </p>
                            </span>
                          }
                          position="right"
                          size="l"
                        />
                      </span>
                    </span>
                  }
                  checked={form.enableProxyChecked}
                  onChange={e => setState({...form, [e.target.name]: e.target.checked})}
                />
              </EuiFormRow>
              {form.enableProxyChecked && (
                <div>
                  <EuiSpacer size="l" />
                  <EuiFormRow label="Server" isInvalid={errors.proxyServer !== undefined}>
                    <EuiFieldText
                      name="proxyServer"
                      value={form.proxyServer}
                      onChange={e => {
                        let newErrors = errors;
                        delete newErrors.proxyServer;
                        setErrors(newErrors);
                        setState({...form, [e.target.name]: e.target.value});
                      }}
                      onKeyPress={e => keyPressed(e)}
                      isInvalid={errors.proxyServer !== undefined} />
                  </EuiFormRow>
                  <EuiFormRow label="Port" isInvalid={errors.proxyPort !== undefined}>
                    <EuiFieldText
                      name="proxyPort"
                      value={form.proxyPort}
                      onChange={e => {
                        let newErrors = errors;
                        delete newErrors.proxyPort;
                        setErrors(newErrors);
                        setState({...form, [e.target.name]: e.target.value});
                      }}
                      onKeyPress={e => keyPressed(e)}
                      isInvalid={errors.proxyPort !== undefined} />
                  </EuiFormRow>
                  <EuiFormRow>
                    <EuiCallOut
                      size="s"
                      title="Testing connection can take up to 60 seconds with proxy settings enabled."
                      iconType="pin"
                    />
                  </EuiFormRow>
                </div>
              )}
            </EuiPanel>
            <EuiSpacer />
            <EuiPanel paddingSize="l" hasShadow>
              <EuiPageContentHeader>
                <EuiTitle>
                  <h2>
                    <FormattedMessage
                      id="domaintoolsPlugin.sslTitle"
                      defaultMessage="SSL"
                    />
                  </h2>
                </EuiTitle>
              </EuiPageContentHeader>
              <EuiFormRow>
                <EuiCheckbox
                  id="customCertificateChecked"
                  name="customCertificateChecked"
                  label={
                    <span>
                      Custom Certificate
                      <span style={{padding: 10 + 'px'}}>
                        <EuiIconTip
                          content={
                            <span>
                              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                If 'Custom Certificate' is checked, Certificate Path must be provided for a successful connection.
                              </p>
                            </span>
                          }
                          position="right"
                          size="l"
                        />
                      </span>
                    </span>
                  }
                  checked={form.customCertificateChecked}
                  onChange={e => setState({...form, [e.target.name]: e.target.checked}) }
                />
              </EuiFormRow>
              {form.customCertificateChecked &&
                <div>
                  <EuiSpacer size="l" />
                  <EuiFormRow label="Custom SSL Certificate Path" isInvalid={errors.customCertificatePath !== undefined}>
                    <EuiFieldText
                      name="customCertificatePath"
                      value={form.customCertificatePath}
                      onChange={e => {
                        let newErrors = errors;
                        delete newErrors.customCertificatePath;
                        setErrors(newErrors);
                        setState({...form, [e.target.name]: e.target.value});
                      }}
                      onKeyPress={e => keyPressed(e)}
                      isInvalid={errors.customCertificatePath !== undefined} />
                  </EuiFormRow>
                </div>
              }
            </EuiPanel>
            <EuiSpacer />
            <EuiFormRow>
              <EuiFlexGroup gutterSize="s" alignItems="center">
                <EuiFlexItem grow={false}>
                  <EuiButton fill onClick={testConnection} disabled={isLoading}>
                    Test Connection
                  </EuiButton>
                </EuiFlexItem>
                { !_.isEqual(previousState, form) &&
                  <EuiFlexItem grow={false}>
                    <EuiButton fill onClick={handleSave} disabled={isLoading}>
                      Save Settings
                    </EuiButton>
                  </EuiFlexItem>
                }
              </EuiFlexGroup>
            </EuiFormRow>
            <EuiFormRow>
              {isLoading ? (
                <EuiText>
                  <EuiSpacer size="l" />
                  <EuiLoadingSpinner size="xl" />
                </EuiText>
              ) : (
                <EuiText>
                  <EuiSpacer size="l" />
                  {output}
                </EuiText>
              )}
            </EuiFormRow>
          </EuiForm>
        </Fragment>
      </EuiPageContentBody>
    </div>
  );
}
