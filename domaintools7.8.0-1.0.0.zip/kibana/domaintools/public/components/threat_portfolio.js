import React, { useState, useEffect, Fragment } from 'react';
import {
  EuiIcon,
  EuiIconTip,
  EuiLoadingSpinner,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiSpacer,
  EuiTitle,
} from '@elastic/eui';
import {
  Axis,
  Chart,
  CurveType,
  LineSeries,
  niceTimeFormatByDay,
  Position,
  ScaleType,
  Settings,
  timeFormatter,
} from '@elastic/charts';
import { euiPaletteColorBlind } from '@elastic/eui/lib/services';
import { FormattedMessage } from '@kbn/i18n/react';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';

export function ThreatPortfolio(props) {
  const [chartData, setChartData] = useState({})
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();

  const eachDataCall = async key => {
    const riskScoreThreshold = props.settings.risk_score_threshold;
    const rangeKey = `domaintools.threat_profile_${key}`
    const query = {
      "size": 0,
      "query": {
        "bool": {
          "filter": [
            {"range": {"@timestamp": {"gte": `now-${props.timeframe}/m`, "lte": "now/m"}}},
            {"range": {[rangeKey]: {"gte": riskScoreThreshold, "lte": 100}}},
          ]
        }
      },
      "aggs": {
        "threats": {
          "date_histogram": {
            "field": "@timestamp",
            "interval": "hour",
            "format": "yyyy-MM-dd HH:mm",
            "order" : { "_key" : "asc" }
          }
        }
      }
    };
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
      },
      body: JSON.stringify(query)
    };
    const index = props.settings.log_indices ? props.settings.log_indices.join(',') : '*';
    const response = await fetchData(`../api/domaintools/es/${index}/search`, options);
    if(response.ok){
      if (response.data.aggregations) {
        const buckets = response.data.aggregations.threats.buckets;
        if (buckets.length > 0) {
          const formattedData = buckets.map((threat) => [threat.key, threat.doc_count])
          return formattedData;
        }
      }
    } else {
      audit("Debug", "Error", `Error getting threat portfolio data for ${key}`, "Dashboard", "DT UI Plugin");
      setAlerts([{message: response.error.msg, statusType: "danger"}])
      return [];
    }
  }

  const getData = async () => {
    return Promise.all(
      ["malware", "phishing", "spam"].map(
        async key => {
          const data = await eachDataCall(key);
          return {[key]: data == null ? [] : data};
        }
      )
    )
  }
  
  useEffect(() => {
    async function getThreats() {
      if(typeof props.settings !== 'undefined' && !_.isEmpty(props.settings) && props.timeframe){
        getData().then(data => {
          if (isMountedRef.current){
            const threats = Object.assign({}, ...data.map(item => item));
            setChartData(threats)
          }
        });
      }
    }
    getThreats();
  }, [props]);

  const timeFrameToDays = {
    "4h": 0,
    "1d": 1,
    "7d": 7,
    "15d": 15,
    "30d": 30,
    "60d": 60
  }

  const dateFormatter = timeFormatter(niceTimeFormatByDay(timeFrameToDays[props.timeframe] || 0));

  return(
    <div>
      <Alert alerts={alerts} />
      <EuiPageContentHeader>
        <EuiTitle data-id="threatPortfolioTitle">
          <h2>
            <EuiIcon size="xl" type="folderClosed" color="default" /> 
            <FormattedMessage
              id="domaintoolsPlugin.threatPortfolioTitle"
              defaultMessage="Threat Portfolio" />
            <span style={{padding: 10 + 'px'}}>
              <EuiIconTip
                content={
                  <span>
                    <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                      Trendline for Malware, Phishing &amp; Spam Domains observed by DomainTools over time.
                    </p>
                    <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                      This chart is not drillable but you can filter on the Threat Type by clicking the legends on the right.
                    </p>
                  </span>
                }
                position="right"
                size="l"
              />
            </span>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        {_.isEmpty(chartData) ? (
          <div>
            <EuiSpacer size="l" />
            <EuiLoadingSpinner size="xl" />
          </div>
        ) : (
          <Chart size={{height: 200}}>
            <Settings
              theme={[{ colors: { vizColors: euiPaletteColorBlind }} ]}
              showLegend
              showLegendExtra
              legendPosition={Position.Right}
            />
            <Axis
              id="bottom-axis"
              position={Position.Bottom}
              showOverlappingTicks
              showGridLines
              tickFormat={dateFormatter}
            />
            <Axis
              id="left-axis"
              showOverlappingTicks
              position={Position.Left}
              showGridLines
            />
            <LineSeries
              id="Malware"
              xScaleType={ScaleType.Time}
              yScaleType={ScaleType.Linear}
              xAccessor={0}
              yAccessors={[1]}
              data={chartData.malware}
              curve={CurveType.CURVE_NATURAL}
            />
            <LineSeries
              id="Phishing"
              xScaleType={ScaleType.Time}
              yScaleType={ScaleType.Linear}
              xAccessor={0}
              yAccessors={[1]}
              data={chartData.phishing}
              curve={CurveType.CURVE_NATURAL}
            />
            <LineSeries
              id="Spam"
              xScaleType={ScaleType.Time}
              yScaleType={ScaleType.Linear}
              xAccessor={0}
              yAccessors={[1]}
              data={chartData.spam}
              curve={CurveType.CURVE_NATURAL}
            />
          </Chart>
        )}
      </EuiPageContentBody>
    </div>
  )
}
