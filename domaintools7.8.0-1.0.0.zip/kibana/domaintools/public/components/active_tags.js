import React, { Fragment, useState, useEffect } from 'react';
import {
  EuiBasicTable,
  EuiIcon,
  EuiIconTip,
  EuiLink,
  EuiLoadingSpinner,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiSpacer,
  EuiTitle,
} from '@elastic/eui';
import chrome from 'ui/chrome';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';
import { FormattedMessage } from '@kbn/i18n/react';

export function ActiveTags(props) {
  const [isLoading, setIsLoading] = useState(true);
  const [tags, setTags] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getTags() {
      if(props.timeframe && typeof props.settings !== 'undefined' && !_.isEmpty(props.settings)){
        const query ={
          "size": 0,
          "query": {
            "bool": {
              "filter": [
                {"range": {"@timestamp": {"gte": `now-${props.timeframe}`}}}
              ]
            }
          },
          "aggs": {
            "tags": {
              "terms": {
                "field": "domaintools.enrich_tag_name.keyword",
                "order": { "_key": "asc" }
              }
            }
          }
        };
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'kbn-xsrf': 'kibana',
          },
          body: JSON.stringify(query)
        };
        setIsLoading(true);
        const index = props.settings.log_indices ? props.settings.log_indices.join(',') : '*';
        const response = await fetchData(`../api/domaintools/es/${index}/search`, options);
        if (isMountedRef.current){
          if(response.ok) {
            if (response.data.aggregations) {
              const tags = response.data.aggregations.tags.buckets;
              if (tags.length > 0) {
                const data = tags.map((tag) => tag.key);
                setTags(data);
              }
            }
          } else {
            audit("Debug", "Error", "Error getting active tags", "Dashboard", "DT UI Plugin");
            setAlerts([{message: response.error.msg, statusType: "danger"}])
          }
          setIsLoading(false);
        }
      }
    }
    getTags();
  }, [props]) 

  const items = tags.map(tag => {
    const index = props.settings.log_indices ? props.settings.log_indices.join(',') : '*';
    const url = chrome.addBasePath(`/app/kibana#/discover?_g=(refreshInterval:(pause:!t,value:0),time:(from:now-${props.timeframe},to:now))&_a=(columns:!(_source),index:'${index}',interval:auto,query:(language:kuery,query:'domaintools.enrich_tag_name:%20${tag}'),sort:!(!('@timestamp',desc)))`);
    return <li key={tag}><EuiLink href={url} external="true" target="_blank">{tag}</EuiLink></li>
  });
  
  const columns = [
    {
      field: 'name',
      name: 'Name',
    },
    {
      field: 'taggedDate',
      name: 'Tagged Date',
    },
    {
      field: 'uniqueNumberOfTaggedDomains',
      name: 'Unique # of Tagged Domains',
    },
  ];

  return(
    <Fragment>
      <Alert alerts={alerts} />
      <EuiPageContentHeader>
        <EuiTitle data-id="activeTagsTitle">
          <h2>
            <EuiIcon size="xl" type="tag" color="default" />
            <FormattedMessage
              id="domaintoolsPlugin.activeTagsTitle"
              defaultMessage="Active Tags" />
            <span style={{padding: 10 + 'px'}}>
              <EuiIconTip
                content={
                  <span>
                    <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                      DomainTools Iris Tags associated with Observabls from your network
                    </p>
                  </span>
                }
                position="right"
                size="l"
              />
            </span>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        {isLoading ? (
          <Fragment>
            <EuiSpacer size="l" />
            <EuiLoadingSpinner size="xl" />
          </Fragment>
        ) : (
          <EuiBasicTable
            items={tags}
            columns={columns}
          />
        )}
      </EuiPageContentBody>
    </Fragment>
  )
}