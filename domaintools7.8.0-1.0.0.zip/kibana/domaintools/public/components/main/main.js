import React, { useState } from 'react';
import {
  EuiBetaBadge,
  EuiContextMenu,
  EuiHeader,
  EuiHeaderLinks,
  EuiHeaderLink,
  EuiHeaderSectionItem,
  EuiIcon,
  EuiPage,
  EuiPageBody,
  EuiPageContent,
  EuiPageContentBody,
  EuiPopover,
} from '@elastic/eui';
import chrome from 'ui/chrome';
import { ApiSettings } from '../api_settings';
import { Dashboard } from '../dashboard';
import { DomainProfile } from '../domain_profile';
import { AppSettings } from '../app_settings';
import { Allowlist } from '../allowlist';
import domaintoolsSvg from '../../images/domaintools.svg';


function flattenPanelTree(tree, array = []) {
  array.push(tree);

  if (tree.items) {
    tree.items.forEach(item => {
      if (item.panel) {
        flattenPanelTree(item.panel, array);
        item.panel = item.panel.id;
      }
    });
  }

  return array;
}

export function Main() {
  const makeApiSettingsVisible = () => {
    makeVisible('apiSettings');
  }
  const VISIBLE_COMPONENT = {
    dashboard: <Dashboard />,
    domainProfile: <DomainProfile makeApiSettingsVisible={makeApiSettingsVisible}/>,
    apiSettings: <ApiSettings />,
    configureApp: <AppSettings />,
    allowlist: <Allowlist />
  }
  const [isSettingsContextOpen, setIsSettingsContextOpen] = useState(false);
  const [visibleComponent, setVisibleComponent] = useState(VISIBLE_COMPONENT['dashboard'])
  
  const makeVisible = (componentName) => {
    setVisibleComponent(VISIBLE_COMPONENT[componentName])
  }
  
  const onSettingsClick = () => {
    setIsSettingsContextOpen(!isSettingsContextOpen)
  };

  const closeSettingsContext = () => {
    setIsSettingsContextOpen(false)
  };

  const settingsLink = (
    <EuiHeaderLink
      data-id='settingsHeaderLink'
      iconType="gear"
      href="#"
      onClick={onSettingsClick}>
        Settings
    </EuiHeaderLink>
  );
  
  const panelTree = {
    id: 0,
    items: [
      {
        name: 'Configure API',
        'data-id': 'apiSettingsBtn',
        onClick: () => {
          closeSettingsContext();
          makeVisible('apiSettings');
        },
      },
      {
        name: 'Configure App',
        'data-id': 'appSettingsBtn',
        onClick: () => {
          closeSettingsContext();
          makeVisible('configureApp');
        },
      },
      {
        name: 'Configure Allowlist',
        'data-id': 'allowlistBtn',
        onClick: () => {
          closeSettingsContext();
          makeVisible('allowlist');
        },
      },
      {
        name: 'Audit Log',
        'data-id': 'auditLogBtn',
        onClick: () => {
          const url = chrome.addBasePath(`/app/kibana#/discover?_g=()&_a=(columns:!(_source),index:'dt-audit*',interval:auto,query:(language:kuery,query:''),sort:!(!(entry_timestamp,desc)))`)
          window.open(url, '_blank');
        },
      },
      {
        name: 'Cache',
        'data-id': 'cacheBtn',
        onClick: () => {
          const url = chrome.addBasePath(`/app/kibana#/discover?_g=()&_a=(columns:!(_source),index:'dt-enrichment*',interval:auto,query:(language:kuery,query:''),sort:!(!(last_enriched,desc)))`);
          window.open(url, '_blank');
        },
      },
    ],
  };
  
  const { version } = require('./../../../package.json');

  const panels = flattenPanelTree(panelTree);

  return (
    <EuiPage>
      <EuiPageBody>
        <EuiHeader>
          <EuiHeaderSectionItem border="right">
            <span style={{padding: 10 + 'px' }}>
              <EuiIcon type={domaintoolsSvg} size="xl" title="DomainTools" />
            </span>
            <span className="euiHeaderLogo__text">DomainTools</span>
            <span style={{paddingLeft: 10 + 'px', paddingRight: 10 + 'px'}}>
              <EuiBetaBadge
                label="Beta"
                tooltipContent={`This plugin is not GA. Please help us by reporting any bugs. Current version is ${version}`}
              />
            </span>
          </EuiHeaderSectionItem>
          <EuiHeaderLinks>
            <EuiHeaderLink href="#" onClick={() => makeVisible('dashboard')}>
              Dashboard
            </EuiHeaderLink>
            <EuiHeaderLink data-id="domainProfileHeaderLink" href="#" onClick={() => makeVisible('domainProfile')}>
              Domain Profile
            </EuiHeaderLink>
            <EuiPopover
              ownFocus
              id="contextMenu"
              button={settingsLink}
              isOpen={isSettingsContextOpen}
              closePopover={closeSettingsContext}
              panelPaddingSize="none"
              hasArrow={false}
              withTitle
              anchorPosition="downLeft">
              <EuiContextMenu initialPanelId={0} panels={panels} />
            </EuiPopover>
          </EuiHeaderLinks>
        </EuiHeader>
        <EuiPageContent>
          <EuiPageContentBody>
            {visibleComponent}
          </EuiPageContentBody>
        </EuiPageContent>
      </EuiPageBody>
    </EuiPage>
  );
}
