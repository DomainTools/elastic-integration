import React, { useEffect, useState } from 'react';
import {
  EuiButton,
  EuiCallOut,
  EuiCheckbox,
  EuiConfirmModal,
  EuiFieldText,
  EuiFlexGrid,
  EuiFlexGroup,
  EuiFlexItem,
  EuiForm,
  EuiFormRow,
  EuiIconTip,
  EuiLoadingSpinner,
  EuiOverlayMask,
  EuiPageContentBody,
  EuiPanel,
  EuiSpacer,
  EuiText,
  EuiTitle,
} from '@elastic/eui';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';


export function AppSettings() {
  const [modalState, setModalState] = useState({
    isModalVisible: false,
  });
  const [output, setOutput] = useState(<div/>);
  const [isLoading, setIsLoading] = useState(false);
  const [alerts, setAlerts] = useState([]);
  const [form, setState] = useState({
    documentId: null,
    securityKey: '',
    batchSize: '100',
    ttlCache: '30',
    disableCache: false,
    riskScoreThreshold: '70',
    threatProfileScoreThreshold: '70',
    proximityScoreThreshold: '80',
    domainAgeThreshold: '7',
    pivotThreshold: '500',
    serviceUrl: 'http://localhost:8000',
  });
  const [previousState, setPreviousState] = useState(form);
  const [errors, setErrors] = useState([]);
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getSettings() {
      setIsLoading(true);
      const settingsDocumentId = "1";
      const response = await fetchData(`../api/domaintools/es/dt-settings/${settingsDocumentId}`);
      if (isMountedRef.current){
        if (response.ok) {
          if (response.data._source) {
            const source = response.data._source;
            let elasticData = {
              documentId: settingsDocumentId,
              securityKey: source.security_key,
              batchSize: source.batch_size || form.batchSize,
              ttlCache: source.ttl_cache || form.ttlCache,
              disableCache: source.disable_cache || form.disableCache,
              riskScoreThreshold: source.risk_score_threshold || form.riskScoreThreshold,
              threatProfileScoreThreshold: source.threat_profile_score_threshold || form.threatProfileScoreThreshold,
              proximityScoreThreshold: source.proximity_score_threshold || form.proximityScoreThreshold,
              domainAgeThreshold: source.domain_age_threshold || form.domainAgeThreshold,
              pivotThreshold: source.pivot_threshold || form.pivotThreshold,
              serviceUrl: source.service_url || form.serviceUrl,
            };
            // If values have never been saved before use defaults
            if (typeof elasticData.batchSize !== 'undefined') {
              setState(elasticData);
              setPreviousState(elasticData);
            } else {
              // no matter if saved before, always load the documentId
              // to allow for future updates of dt-settings index
              setState({ ...form, documentId: elasticData.documentId });
            }
          }
        } else {
          audit("Debug", "Error", "Error getting settings", "AppConfig", "DT UI Plugin");
          setAlerts([{ message: response.error.msg, statusType: 'danger' }]);
        }
        setIsLoading(false);
      }
    }

    getSettings();
  }, []);

  const closeModal = () => {
    setModalState({ isModalVisible: false });
  };

  const showModal = () => {
    setModalState({ isModalVisible: true });
  };

  const flushCache = async () => {
    console.log('flushing cache');
    setIsLoading(true);
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
      },
      body: JSON.stringify({
        securityKey: form.securityKey,
        serviceUrl: form.serviceUrl
      }),
    };
    let response = await fetchData(`../api/domaintools/flush_cache`, options);
    if (response.ok) {
      setAlerts([{ message: 'DomainTools enrichment cache has been flushed.', statusType: 'success' }]);
    } else {
      audit("Debug", "Error", "Error flushing cache", "AppConfig", "DT UI Plugin");
      setAlerts([{ message: response.error, statusType: 'danger' }]);
    }
    setIsLoading(false);
    closeModal();
  };

  const isValid = () => {
    setErrors({});
    let validationErrors = {};
    let batchSize = parseInt(form.batchSize);
    let ttlCache = parseInt(form.ttlCache);
    let riskScoreThreshold = parseInt(form.riskScoreThreshold);
    let threatProfileScoreThreshold = parseInt(form.threatProfileScoreThreshold);
    let proximityScoreThreshold = parseInt(form.proximityScoreThreshold);
    let domainAgeThreshold = parseInt(form.domainAgeThreshold);
    let pivotThreshold = parseInt(form.pivotThreshold);
    if (batchSize > 100 || batchSize < 1 || isNaN(batchSize)) {
      validationErrors.batchSize = 'Batch Size must be a number between 1-100';
    }
    if (ttlCache < 1 || isNaN(ttlCache)) {
      validationErrors.ttlCache = 'TTL Cache must be a number greater than 0';
    }
    if (riskScoreThreshold > 100 || riskScoreThreshold < 0 || isNaN(riskScoreThreshold)) {
      validationErrors.riskScoreThreshold = 'Risk Score Threshold must be a number between 0-100';
    }
    if (threatProfileScoreThreshold > 100 || threatProfileScoreThreshold < 0 || isNaN(threatProfileScoreThreshold)) {
      validationErrors.threatProfileScoreThreshold = 'Threat Profile Score Threshold must be a number between 0-100';
    }
    if (proximityScoreThreshold > 100 || proximityScoreThreshold < 0 || isNaN(proximityScoreThreshold)) {
      validationErrors.proximityScoreThreshold = 'Proximity Score Threshold must be a number between 0-100';
    }
    if (domainAgeThreshold < 1 || isNaN(domainAgeThreshold)) {
      validationErrors.domainAgeScoreThreshold = 'Domain Age Threshold must be a number greater than 0';
    }
    if (pivotThreshold < 1 || isNaN(pivotThreshold)) {
      validationErrors.pivotThreshold = 'Pivot Threshold must be a number greater than 0';
    }
    if (!form.serviceUrl) {
      validationErrors.serviceUrl = 'Service URL can\'t be blank';
    }

    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  };


  const refreshServiceSettings = async () => {
    if (isValid()) {
      setIsLoading(true);
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify({
          securityKey: form.securityKey,
          serviceUrl: form.serviceUrl
        }),
      };
      let response = await fetchData(`../api/domaintools/refresh_settings`, options);
      if (response.ok) {
        if (response.data.length > 0) {
          setAlerts([{ message: response.data, statusType: 'success' }]);
        }
      } else {
        audit("Debug", "Error", "Error refreshing service settings", "AppConfig", "DT UI Plugin");
        setAlerts([{ message: response.error, statusType: 'danger' }]);
        return () => {
        };
      }
      setIsLoading(false);
    }

  };

  const handleSave = async () => {
    setOutput('');
    if (isValid()) {
      setIsLoading(true);
      const options = {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify({
          'doc': {
            batch_size: form.batchSize,
            ttl_cache: form.ttlCache,
            disable_cache: form.disableCache,
            risk_score_threshold: form.riskScoreThreshold,
            threat_profile_score_threshold: form.threatProfileScoreThreshold,
            proximity_score_threshold: form.proximityScoreThreshold,
            domain_age_threshold: form.domainAgeThreshold,
            pivot_threshold: form.pivotThreshold,
            service_url: form.serviceUrl,
          },
        }),
      };
      let response = await fetchData(`../api/domaintools/update/es/dt-settings/${form.documentId}`, options);
      if (response.ok) {
        setAlerts([{ message: 'Save Successful!', statusType: 'success' }]);
        await refreshServiceSettings();
      } else {
        audit("Debug", "Error", "Error saving app settings", "AppConfig", "DT UI Plugin");
        setAlerts([{ message: response.error, statusType: 'danger' }]);
      }
      setPreviousState(form);
      setIsLoading(false);
    }
  };

  let modal;
  if (modalState.isModalVisible) {
    modal = (
      <EuiOverlayMask>
        <EuiConfirmModal
          title="Flush Cache?"
          onCancel={closeModal}
          onConfirm={flushCache}
          cancelButtonText="Cancel"
          confirmButtonText="Confirm"
          defaultFocusedButton="confirm">
          <p>You're about to flush the DomainTools enrichment cache.</p>
          <p>Are you sure you want to do this?</p>
        </EuiConfirmModal>
      </EuiOverlayMask>
    );
  }

  return (
    <div>
      <Alert alerts={alerts}/>
      <EuiPageContentBody>
        <EuiFlexGrid columns={2} direction="row">
          <EuiFlexItem>
            <EuiForm isInvalid={Object.keys(errors).length > 0} error={Object.values(errors)}>
              <EuiPanel paddingSize="l" hasShadow>
                <EuiTitle data-id='enrichmentSettingsTitle' size="l"><h1>Enrichment Settings</h1></EuiTitle>
                <EuiFormRow
                  label={
                    <span>
                      Batch Size
                      <span style={{padding: 10 + 'px'}}>
                        <EuiIconTip
                          content={
                            <span>
                              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                Maximum number of domains batched in an API call. Default is 100.
                              </p>
                              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                Valid values are 1-100. Setting a lower value may enable frequent enrichment but consume more queries
                              </p>
                            </span>
                          }
                          position="right"
                          size="l"
                        />
                      </span>
                    </span>
                  }
                  isInvalid={errors.batchSize !== undefined}>
                  <EuiFieldText
                    name="batchSize"
                    value={form.batchSize.toString()}
                    onChange={e => {
                      let newErrors = errors;
                      delete newErrors.batchSize;
                      setErrors(newErrors);
                      setState({ ...form, [e.target.name]: e.target.value });
                    }}
                    isInvalid={errors.batchSize !== undefined}
                  data-id='batchSizeInput'/>
                </EuiFormRow>
                <EuiFormRow
                  label={
                    <span>
                      Cache Retention Period: (In Days)
                      <span style={{padding: 10 + 'px'}}>
                        <EuiIconTip
                          content={
                            <span>
                              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                The number of days after which past enrichment data will be deleted from the cache. Recommended 30-60 days
                              </p>
                              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                A higher value will provide greater historical context, but may present outdated intellgence data.
                              </p>
                            </span>
                          }
                          position="right"
                          size="l"
                        />
                      </span>
                    </span>
                  }
                  isInvalid={errors.ttlCache !== undefined}>
                  <EuiFieldText
                    name="ttlCache"
                    value={form.ttlCache.toString()}
                    onChange={e => {
                      let newErrors = errors;
                      delete newErrors.ttlCache;
                      setErrors(newErrors);
                      setState({ ...form, [e.target.name]: e.target.value });
                    }}
                    isInvalid={errors.ttlCache !== undefined}
                  data-id='ttlCacheInput'/>
                </EuiFormRow>
                <EuiFormRow>
                  <EuiCheckbox
                    id="disableCache"
                    name="disableCache"
                    label={
                      <span>
                        Disable DomainTools Cache?
                        <span style={{padding: 10 + 'px'}}>
                          <EuiIconTip
                            content={
                              <span>
                                <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                  Disabling Cache will retrieve the latest intelligence dataset  from DomainTools. Use this in conjuction with longer cache retention period for optimzing enrichment context.
                                </p>
                                <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                  Caution: Will consume greater API queries.
                                </p>
                              </span>
                            }
                            position="right"
                            size="l"
                          />
                        </span>
                      </span>
                    }
                    checked={form.disableCache}
                    onChange={e => setState({ ...form, [e.target.name]: e.target.checked })}
                    data-id='disableCacheCheckbox'
                  />
                </EuiFormRow>
                <EuiFormRow 
                  label={
                    <span>
                      Service URL
                      <span style={{padding: 10 + 'px'}}>
                        <EuiIconTip
                          content={
                            <span>
                              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                                Endpoint URL for Domaintools backend service
                              </p>
                            </span>
                          }
                          position="right"
                          size="l"
                        />
                      </span>
                    </span>
                  }
                  isInvalid={errors.serviceUrl !== undefined}>
                  <EuiCallOut title="Caution" color="warning" iconType="help">
                    <p>
                      DomainTools Kibana plugin utilizes this URL to communicate
                      with its backend service. If the URL is invalid, DomainTools
                      related data will NOT be saved to DomainTools ElasticSearch index.
                    </p>
                    <EuiFieldText
                      name="serviceUrl"
                      value={form.serviceUrl}
                      onChange={e => {
                        let newErrors = errors;
                        delete newErrors.serviceUrl;
                        setErrors(newErrors);
                        setState({ ...form, [e.target.name]: e.target.value });
                      }}
                      isInvalid={errors.serviceUrl !== undefined}
                    data-id='serviceUrlInput'/>
                  </EuiCallOut>
                </EuiFormRow>
                <EuiFormRow>
                  <EuiCallOut title="Caution" color="warning" iconType="help">
                    <p>
                      This will delete all entries from the dt-enrichment index.
                      You'll likely want to do this if you suspect there are some stale
                      domain intelligence from the past or start fresh.
                    </p>
                    <EuiButton data-id='flushCacheBtn' fill color="warning" onClick={showModal}>
                      Flush Cache
                    </EuiButton>
                  </EuiCallOut>
                </EuiFormRow>
              </EuiPanel>
            </EuiForm>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiPanel paddingSize="l" hasShadow>
              <EuiTitle data-id='threatIntelligenceSettingsTitle' size="l"><h1>Threat Intelligence Dashboard Settings</h1></EuiTitle>
              <EuiFormRow
                label={
                  <span>
                    Risk Score Threshold
                    <span style={{padding: 10 + 'px'}}>
                      <EuiIconTip
                        content={
                          <span>
                            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                            Customize any of the below score thresholds based on your organizations risk posture. The values are used in the Threat Intelligence dashboard for filtering purposes.
                            </p>
                            <span style={{margin: 10 + 'px'}}>
                              Default values:
                              <ul>
                                <li>- Risk Score Threshold: 70</li>
                                <li>- Threat Profile Score Threshold: 70</li>
                                <li>- Proximity Score Threshold: 70</li>
                                <li>- Age of Young Domains: 15</li>
                                <li>- Guided Pivot Threshold: 500</li>
                              </ul>
                            </span>
                          </span>
                        }
                        position="right"
                        size="l"
                      />
                    </span>
                  </span>
                }
                isInvalid={errors.riskScoreThreshold !== undefined}>
                <EuiFieldText
                  name="riskScoreThreshold"
                  value={form.riskScoreThreshold.toString()}
                  onChange={e => {
                    let newErrors = errors;
                    delete newErrors.riskScoreThreshold;
                    setErrors(newErrors);
                    setState({ ...form, [e.target.name]: e.target.value });
                  }}
                  isInvalid={errors.riskScoreThreshold !== undefined}
                data-id='riskScoreThresholdInput'/>
              </EuiFormRow>
              <EuiFormRow label="Threat Profile Score Threshold"
                          isInvalid={errors.threatProfileScoreThreshold !== undefined}>
                <EuiFieldText
                  name="threatProfileScoreThreshold"
                  value={form.threatProfileScoreThreshold.toString()}
                  onChange={e => {
                    let newErrors = errors;
                    delete newErrors.threatProfileScoreThreshold;
                    setErrors(newErrors);
                    setState({ ...form, [e.target.name]: e.target.value });
                  }}
                  isInvalid={errors.threatProfileScoreThreshold !== undefined}
                data-id='threatProfileScoreThresholdInput'/>
              </EuiFormRow>
              <EuiFormRow label="Proximity Score Threshold" isInvalid={errors.proximityScoreThreshold !== undefined}>
                <EuiFieldText
                  name="proximityScoreThreshold"
                  value={form.proximityScoreThreshold.toString()}
                  onChange={e => {
                    let newErrors = errors;
                    delete newErrors.proximityScoreThreshold;
                    setErrors(newErrors);
                    setState({ ...form, [e.target.name]: e.target.value });
                  }}
                  isInvalid={errors.proximityScoreThreshold !== undefined}
                data-id='proximityScoreThresholdInput'/>
              </EuiFormRow>
              <EuiFormRow
                label={
                  <span>
                    Age of Young Domains
                    <span style={{padding: 10 + 'px'}}>
                      <EuiIconTip
                        content={
                          <span>
                            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                              Customize how you define Young domains in number of days.
                            </p>
                            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                              This feature leverages the Domain creation date in our intelligence dataset.
                            </p>
                          </span>
                        }
                        position="right"
                        size="l"
                      />
                    </span>
                  </span>
                }
                isInvalid={errors.domainAgeThreshold !== undefined}>
                <EuiFieldText
                  name="domainAgeThreshold"
                  value={form.domainAgeThreshold.toString()}
                  onChange={e => {
                    let newErrors = errors;
                    delete newErrors.domainAgeThreshold;
                    setErrors(newErrors);
                    setState({ ...form, [e.target.name]: e.target.value });
                  }}
                  isInvalid={errors.domainAgeThreshold !== undefined}
                data-id='domainAgeThresholdInput'/>
              </EuiFormRow>
              <EuiFormRow
                label={
                  <span>
                    Guided Pivot Threshold
                    <span style={{padding: 10 + 'px'}}>
                      <EuiIconTip
                        content={
                          <span>
                            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                              “Guided Pivots” automatically shows the analyst which pivots are most likely to lead to relevant connections in the Domain Profile pane.
                            </p>
                            <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                              This threshold value is used to highlight any domain attributes connected with potentially  malicious infrastructure components in our dataset.
                            </p>
                          </span>
                        }
                        position="right"
                        size="l"
                      />
                    </span>
                  </span>
                }
                isInvalid={errors.pivotThreshold !== undefined}>
                <EuiFieldText
                  name="pivotThreshold"
                  value={form.pivotThreshold.toString()}
                  onChange={e => {
                    let newErrors = errors;
                    delete newErrors.pivotThreshold;
                    setErrors(newErrors);
                    setState({ ...form, [e.target.name]: e.target.value });
                  }}
                  isInvalid={errors.pivotThreshold !== undefined}
                data-id='pivotThresholdInput'/>
              </EuiFormRow>
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGrid>
        <EuiSpacer/>
        <EuiFormRow>
          <EuiFlexGroup gutterSize="s" alignItems="center">
            {!_.isEqual(previousState, form) &&
            <EuiFlexItem grow={false}>
              <EuiButton data-id='appSaveSettingsBtn' fill onClick={handleSave} disabled={isLoading}>
                Save Settings
              </EuiButton>
            </EuiFlexItem>
            }
          </EuiFlexGroup>
        </EuiFormRow>
        <EuiSpacer/>
        <EuiFormRow>
          {isLoading ? (
            <EuiText>
              <EuiSpacer size="l"/>
              <EuiLoadingSpinner size="xl"/>
            </EuiText>
          ) : (
            <EuiText>
              <EuiSpacer size="l"/>
              {output}
            </EuiText>
          )}
        </EuiFormRow>

      </EuiPageContentBody>
      {modal}
    </div>
  );
}
