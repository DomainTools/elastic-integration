import React from 'react';
import { EuiBasicTable, EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { GuidedPivotTextAndTooltip } from './guided_pivot_text_and_tooltip'

export function MailServerTable(props) {
  const columns = [
    {
      field: 'domain',
      name: 'Domain',
      render: (domain, item) => {
        return <GuidedPivotTextAndTooltip count={item.domain_count} text={domain} pivotThreshold={props.pivotThreshold} />
      },
    },
    {
      field: 'host',
      name: 'Host',
      render: (host, item) => {
        return <GuidedPivotTextAndTooltip count={item.host_count} text={host} pivotThreshold={props.pivotThreshold} />
      },
    },
    {
      field: 'ips',
      name: 'IPs',
    },
    {
      field: 'priority',
      name: 'Priority',
    },
  ];

  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.mailServerTableTitle"
              defaultMessage={props.title}/>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiBasicTable
          items={props.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
