import React, { Fragment, useState, useEffect } from 'react';
import {
  EuiCard,
  EuiIcon,
  EuiLoadingSpinner,
  EuiSpacer,
  EuiToolTip,
} from '@elastic/eui';
import chrome from 'ui/chrome';
import { Alert } from './alert';
import { audit, fetchData, useIsMountedRef } from '../helpers';

export function SuspicousDomains(props) {
  const [isLoading, setIsLoading] = useState(true);
  const [suspiciousDomains, setSuspiciousDomains] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getDomains() {
      if(props.timeframe && !_.isEmpty(props.settings)){
        const riskScoreThreshold = props.settings.risk_score_threshold;
        const query = {
          "size": 0,
          "query": {
            "bool": {
              "filter": [
                {"range": {"@timestamp": {"gte": `now-${props.timeframe}/m`, "lt": "now/m"}}},
                {"range": {"DomainToolsIris.risk_score": {"gt": riskScoreThreshold, "lte": 100}}},
              ]
            }
          },
          "aggs": {
            "suspicious_domains": {
              "value_count": { "field": "_id" }
            }
          }
        };
        if(!_.isEmpty(props.allowlist)){
          const allowlistExclusion = props.allowlist.map(domain => ({"term": {"DomainToolsIris.domain_name": domain}}));
          query.query.bool["must_not"] = allowlistExclusion;
        }
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'kbn-xsrf': 'kibana',
          },
          body: JSON.stringify(query)
        };
        setIsLoading(true);
        const response = await fetchData("../api/domaintools/es/dt-enrichment/search", options);
        if (isMountedRef.current) {
          if(response.ok){
            if (response.data.aggregations) {
              setSuspiciousDomains(response.data.aggregations.suspicious_domains.value);
            }
          } else {
            audit("Debug", "Error", "Error getting suspicious domains", "Dashboard", "DT UI Plugin");
            setAlerts([{message: response.error.msg, statusType: "danger"}])
          }
          setIsLoading(false);
        }
      }
    }
    getDomains();
  }, [props]);

  const handleOnClick = () => {
    let allowlistPartOfQuery = "";
    if(!_.isEmpty(props.allowlist)){
      allowlistPartOfQuery = props.allowlist.map(domain => `%20AND%20not%20DomainToolsIris.domain_name:%20${domain}`).join("")
    }
    const url = chrome.addBasePath(`/app/kibana#/discover?_g=(refreshInterval:(pause:!t,value:0),time:(from:now-${props.timeframe}%2Fm,to:now))&_a=(columns:!(_source),index:'dt-enrichment*',interval:auto,query:(language:kuery,query:'DomainToolsIris.risk_score%3E${props.settings.risk_score_threshold}${allowlistPartOfQuery}'),sort:!(!(_score,desc)))`);
    window.open(url, '_blank');
  }

  return(
    <Fragment>
      <Alert alerts={alerts} />
      {isLoading ? (
        <Fragment>
          <EuiSpacer size="l" />
          <EuiLoadingSpinner size="xl" />
        </Fragment>
      ) : (
        <EuiToolTip
          position="top"
          content={
            <span>
              <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                Count of Unique Domains that are not in DomainTools Allowlist and
                DomainTools Risk Score is greater than the risk score thresholds configured
              </p>
            </span>
        }>
          <EuiCard
            data-id="suspiciousDomainsTitle"
            icon={<EuiIcon size="xxl" type="flag" color="warning" />}
            title={<Fragment>{"Suspicious Domains"}<EuiSpacer size="xxl" /></Fragment>}
            description={
              <b style={{fontSize: 2.5 + 'rem'}}>{suspiciousDomains}</b>
            }
            onClick={handleOnClick} />
        </EuiToolTip>
      )}
    </Fragment>
  )
}