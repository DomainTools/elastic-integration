import React from 'react';
import {
    EuiPageContentBody,
    EuiPageContentHeader,
    EuiPanel,
    EuiTitle,
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';

export function Diagnostics() {
    return(
        <div>
            <EuiPageContentHeader>
                <EuiTitle>
                    <h2>
                        <FormattedMessage
                            id="domaintoolsPlugin.diagnosticsTitle"
                            defaultMessage="Diagnostics" />
                    </h2>
                </EuiTitle>
            </EuiPageContentHeader>
            <EuiPageContentBody>
                <EuiPanel paddingSize="l" hasShadow>
                    <div>Coming Soon...</div>
                </EuiPanel>
            </EuiPageContentBody>
        </div>
    )
}