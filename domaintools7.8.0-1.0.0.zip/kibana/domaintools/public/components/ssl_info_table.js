import React from 'react';
import { EuiBasicTable, EuiPageContentBody, EuiPageContentHeader, EuiTitle } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { GuidedPivotTextAndTooltip } from './guided_pivot_text_and_tooltip'

export function SSLInfoTable(props) {
  const columns = [
    {
      field: 'hash',
      name: 'Hash',
      render: (hash, item) => {
        return <GuidedPivotTextAndTooltip count={item.hash_count} text={hash} pivotThreshold={props.pivotThreshold} />
      },
    },
    {
      field: 'subject',
      name: 'Subject',
      render: (subject, item) => {
        return <GuidedPivotTextAndTooltip count={item.subject_count} text={subject} pivotThreshold={props.pivotThreshold} />
      },
    },
    {
      field: 'organization',
      name: 'Organization',
    },
    {
      field: 'emails',
      name: 'Emails',
    },
  ];

  return (
    <div>
      <EuiPageContentHeader>
        <EuiTitle>
          <h2>
            <FormattedMessage
              id="domaintoolsPlugin.sslInfoTableTitle"
              defaultMessage={props.title}/>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        <EuiBasicTable
          items={props.items}
          columns={columns}
        />
      </EuiPageContentBody>
    </div>
  );
}
