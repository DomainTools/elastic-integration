import React, { Fragment, useState, useEffect } from 'react';
import {
  EuiIcon,
  EuiIconTip,
  EuiLoadingSpinner,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiSpacer,
  EuiTitle,
} from '@elastic/eui';
import {
  Axis,
  BarSeries,
  Chart,
  Position,
  ScaleType,
  Settings,
} from '@elastic/charts';
import { euiPaletteColorBlind } from '@elastic/eui/lib/services';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';
import { FormattedMessage } from '@kbn/i18n/react';

export function ActiveDomains(props) {
  const [isLoading, setIsLoading] = useState(true);
  const [chartData, setChartData] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();
  
  useEffect(() => {
    async function getDomains() {
      if(props.timeframe){
        const query = {
          "size": 0,
          "sort" : [
            { "@timestamp" : {"order" : "asc"}},
            { "domaintools.domain_name.keyword" : {"order" : "asc"}}
          ],
          "query": {
            "bool": {
              "filter": [
                {"range": {"@timestamp": {"gte": `now-${props.timeframe}`}}},
              ]
            }
          },
          "aggs": {
            "domains": {
              "terms": { "field": "domaintools.domain_name.keyword" }
            }
          }
        };
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'kbn-xsrf': 'kibana',
          },
          body: JSON.stringify(query)
        };
        setIsLoading(true);
        const index = props.settings.log_indices ? props.settings.log_indices.join(',') : '*';
        const response = await fetchData(`../api/domaintools/es/${index}/search`, options);
        if (isMountedRef.current){
          if(response.ok) {
            if (response.data.aggregations) {
              const domains = response.data.aggregations.domains.buckets;
              if (domains.length > 0) {
                const data = domains.map((domain, index) => ({ x: index+1, y: domain.doc_count, g: domain.key }))
                setChartData(data);
              }
            }
          } else {
            audit("Debug", "Entry", "Error getting active domains", "Dashboard", "DT UI Plugin");
            setAlerts([{message: domains.error.msg, statusType: "danger"}])
          }
          setIsLoading(false);
        }
      }
    }
    getDomains();
  }, [props]);

  return(
    <Fragment>
      <Alert alerts={alerts} />
      <EuiPageContentHeader>
        <EuiTitle data-id="activeDomainsTitle">
          <h2>
            <EuiIcon size="l" type="documents" color="default" />
            <FormattedMessage
              id="domaintoolsPlugin.activeDomainsTitle"
              defaultMessage="Active Domains" />
            <span style={{padding: 10 + 'px'}}>
              <EuiIconTip
                content={
                  <span>
                    <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                      Displays the most active domains observed in your network, associated with the number of events.
                    </p>
                  </span>
                }
                position="right"
                size="l"
              />
            </span>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        {isLoading ? (
          <Fragment>
            <EuiSpacer size="l" />
            <EuiLoadingSpinner size="xl" />
          </Fragment>
        ) : (
          <Chart size={{height: 200}}>
            <Settings
              theme={[
              { colors: { vizColors: euiPaletteColorBlind }},
              ]}
              showLegend
              showLegendExtra
              legendPosition={Position.Right}
            />
            <Axis id="bottom-axis" position={Position.Bottom} title="Domains" tickFormat={(s) => s.domain_name } showOverlappingTicks={true} showGridLines />
            <Axis id="left-axis" title="# of Events" position={Position.Left} tickFormat={(d) => Number(d).toFixed(2)} showGridLines />
            <BarSeries
              id="bars"
              xScaleType={ScaleType.Linear}
              yScaleType={ScaleType.Linear}
              xAccessor="x"
              yAccessors={['y']}
              stackAccessors={['x']}
              splitSeriesAccessors={['g']}
              data={chartData}
            />
          </Chart>
        )}
      </EuiPageContentBody>
    </Fragment>
  )
}