import React, { Fragment, useState, useEffect } from 'react';
import {
  EuiCard,
  EuiIcon,
  EuiLoadingSpinner,
  EuiSpacer,
  EuiToolTip,
} from '@elastic/eui';
import chrome from 'ui/chrome';
import { Alert } from './alert';
import { audit, fetchData, useIsMountedRef } from '../helpers';

export function DangerousDomains(props) {
  const [isLoading, setIsLoading] = useState(true);
  const [dangerousDomains, setDangerousDomains] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();
  
  useEffect(() => {
    async function getDomains() {
      if(props.timeframe && !_.isEmpty(props.settings)){
        const domainAgeThreshold = props.settings.domain_age_threshold;
        const riskScoreThreshold = props.settings.risk_score_threshold;
        const threatProfileScoreThreshold = props.settings.threat_profile_score_threshold;
        const query = {
          "size": 0,
          "query": {
            "bool": {
              "filter": [
                {"range": {"@timestamp": {"gte": `now-${props.timeframe}/m`, "lt": "now/m"}}},
                {"range": {"DomainToolsIris.risk_score": {"gt": riskScoreThreshold, "lte": 100}}},
                {"range": {"DomainToolsIris.domain_create_date": {"gte": `now-${domainAgeThreshold}d/m`, "lt": "now/m"}}},
                {"range": {"DomainToolsIris.threat_profile_risk_score": {"gt": threatProfileScoreThreshold, "lte": 100}}}
              ]
            }
          },
          "aggs": {
            "domains": {
              "value_count": { "field": "_id" }
            }
          }
        };
        if(!_.isEmpty(props.allowlist)){
          const allowlistExclusion = props.allowlist.map(domain => ({"term": {"DomainToolsIris.domain_name": domain}}));
          query.query.bool["must_not"] = allowlistExclusion;
        }
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'kbn-xsrf': 'kibana',
          },
          body: JSON.stringify(query)
        };
        setIsLoading(true);
        const response = await fetchData("../api/domaintools/es/dt-enrichment/search", options);
        if (isMountedRef.current){
          if(response.ok){
            if (response.data.aggregations) {
              setDangerousDomains(response.data.aggregations.domains.value);
            }
          } else {
            audit("Debug", "Error", "Error getting dangerous domains", "Dashboard", "DT UI Plugin");
            setAlerts([{message: response.error.msg, statusType: "danger"}])
          }
          setIsLoading(false);
        }
      }
    }
    getDomains();
  }, [props]);

  const handleOnClick = () => {
    let allowlistPartOfQuery = "";
    if(!_.isEmpty(props.allowlist)){
      allowlistPartOfQuery = props.allowlist.map(domain => `%20AND%20not%20domain_name.keyword:%20${domain}`).join("")
    }
    const daysBefore = new Date(Date.now() - props.settings.domain_age_threshold * 24 * 60 * 60 * 1000).toISOString();
    const url = chrome.addBasePath(`/app/kibana#/discover?_g=(refreshInterval:(pause:!t,value:0),time:(from:now-${props.timeframe}%2Fm,to:now))&_a=(columns:!(_source),index:'dt-enrichment*',interval:auto,query:(language:kuery,query:'DomainToolsIris.risk_score%3E${props.settings.risk_score_threshold}%20AND%20DomainToolsIris.domain_create_date%3E%22${daysBefore}%22%20AND%20DomainToolsIris.threat_profile_risk_score%3E${props.settings.threat_profile_score_threshold}${allowlistPartOfQuery}'),sort:!(!(_score,desc)))`);
    window.open(url, '_blank');
  }

  return(
    <Fragment>
      <Alert alerts={alerts} />
      {isLoading ? (
        <Fragment>
          <EuiSpacer size="l" />
          <EuiLoadingSpinner size="xl" />
        </Fragment>
      ) : (
        <EuiToolTip
          position="top"
          content={
            <span style={{margin: 10 + 'px', textAlign: 'center'}}>
              Count of Unique Domains that are not allowlisted and meets the following criteria:
              <ul>
                <li>- DomainTools Risk Score and Domain Age are greater than the thresholds configured</li>
                <li>- DomainTools Phishing or Malware or Spam score is greater than the risk score threshold configured</li>
              </ul>
            </span>
        }>
            <EuiCard
              data-id="dangerousDomainsTitle"
              icon={<EuiIcon size="xxl" type="alert" color="danger" />}
              title={<Fragment>{"Dangerous Domains"}<EuiSpacer size="xxl" /></Fragment>}
              description={
                <b style={{fontSize: 2.5 + 'rem'}}>{dangerousDomains}</b>
              }
              onClick={handleOnClick} />
        </EuiToolTip>
      )}
    </Fragment>
  )
}