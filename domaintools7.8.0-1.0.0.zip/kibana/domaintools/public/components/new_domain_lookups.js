import React, { Fragment, useEffect, useState } from 'react';
import {
  EuiBasicTable,
  EuiIcon,
  EuiIconTip,
  EuiLoadingSpinner,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiSpacer,
  EuiText,
  EuiTitle,
  EuiToolTip
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { audit, fetchData, useIsMountedRef } from '../helpers';
import { Alert } from './alert';
const moment = require('moment');

export function NewDomainLookups(props) {
  const [isLoading, setIsLoading] = useState(true);
  const [tableData, setTableData] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const isMountedRef = useIsMountedRef();

  useEffect(() => {
    async function getDomains() {

      const query = {
        'size': 20,
        'sort': [
          { 'last_enriched_datetime': { 'order': 'desc' } },
        ],
        'query': {
          'bool': {
            'filter': {
              'bool': {
                'must': [
                  {
                    'range': {
                      'num_of_adhoc_lookups': {
                        'gte': 1,
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      };
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
        },
        body: JSON.stringify(query),
      };
      setIsLoading(true);
      const response = await fetchData('../api/domaintools/es/dt-metadata/search', options);
      if(isMountedRef.current){
        if (response.ok) {
          let tmpArray = [];
          for (const key in response.data.hits.hits) {
            let value = response.data.hits.hits[key];
            tmpArray.push({
              timestamp: _.get(value, '_source.last_enriched_datetime', ''),
              domain_name: _.get(value, '_id', ''),
              risk_score: _.get(value, '_source.risk_score', ''),
            });
          }
          setTableData(tmpArray);
        } else {
          audit("Debug", "Error", "Error getting lookup domains", "Dashboard", "DT UI Plugin");
          setAlerts([{ message: response.error, statusType: 'danger' }]);
        }
        setIsLoading(false);
      }
    }

    getDomains();
  }, [props]);

  const columns = [
    {
      field: 'domain_name',
      name: 'Domain Name',
    },
    {
      field: 'risk_score',
      name: 'Risk Score',
    },
    {
      field: 'timestamp',
      name: 'Query Time',
      render: timestamp => {
        return (
          <EuiToolTip
            position="top"
            content={moment(timestamp).format("dddd, MMMM Do YYYY, h:mm:ss a")}>
            <EuiText>{moment(timestamp).fromNow()}</EuiText>
          </EuiToolTip>
        );
      },
    },
  ];

  return (
    <div>
      <Alert alerts={alerts}/>
      <EuiPageContentHeader>
        <EuiTitle data-id="domainLookupsTitle">
          <h2>
            <EuiIcon size="xl" type="inspect" color="default" />
            <FormattedMessage
              id="domaintoolsPlugin.domainLookupsTitle"
              defaultMessage="Domain Lookups (Recent 20)"/>
            <span style={{padding: 10 + 'px'}}>
              <EuiIconTip
                content={
                  <span>
                    <p style={{margin: 10 + 'px', textAlign: 'center'}}>
                      Recent 20 domains users have researched in your environment
                    </p>
                  </span>
                }
                position="right"
                size="l"
              />
            </span>
          </h2>
        </EuiTitle>
      </EuiPageContentHeader>
      <EuiPageContentBody>
        {isLoading ? (
          <Fragment>
            <EuiSpacer size="l" />
            <EuiLoadingSpinner size="xl" />
          </Fragment>
        ) : (
          <EuiBasicTable
            items={tableData}
            columns={columns}
          />
        )}
      </EuiPageContentBody>
    </div>
  );
}
