import { Selector } from 'testcafe';
import { user } from './helpers';
import {
  settingsHeaderLink,
  allowlistAddButton,
  allowlistErrorForm,
  allowlistInput,
  allowlistLink,
  allowlistRemoveAllButton,
  allowlistSelectAllCheckbox,
  allowlistTitle,
} from './selectors';

const config = require('./config.json');

fixture`Allowlist`
  .page(`${config.baseUrl}app/domaintools`)
  .beforeEach(async (t) => {
    await t.useRole(user)
      .click(settingsHeaderLink)
      .click(allowlistLink);
  });

test('Confirm adds good domain to allowlist', async t => {
  await t
    .expect(Selector(allowlistTitle).innerText).eql('Domain Allowlist')
    .typeText(allowlistInput, 'test.com', { replace: true })
    .click(allowlistAddButton)
    .click(allowlistSelectAllCheckbox)
    .click(allowlistRemoveAllButton)
});

test('Confirm get error when adding bad domain to allowlist', async t => {
  await t
    .expect(Selector(allowlistTitle).innerText).eql('Domain Allowlist')
    .typeText(allowlistInput, 'test', { replace: true })
    .click(allowlistAddButton)
    .expect(Selector(allowlistErrorForm).innerText)
    .contains('test is not a valid domain name')
});

test('Confirm get error when trying to add no domains to allowlist', async t => {
  await t
    .expect(Selector(allowlistTitle).innerText).eql('Domain Allowlist')
    .selectText(allowlistInput)
    .pressKey('delete')
    .click(allowlistAddButton)
    .expect(Selector(allowlistErrorForm).innerText)
    .contains('New domain(s) to add to allowlist is/are blank')
});

//test('Confirm see modal and accept domain change when adding domain with subdomain to allowlist', async t => {
//  await t
//    .expect(Selector(allowlistTitle).innerText).eql('Domain Allowlist')
//    .typeText(allowlistInput, 'x.test.com', { replace: true })
//    .click(allowlistAddButton)
//    .expect(Selector(allowlistErrorForm).innerText)
//    .contains('test is not a valid domain name')
//    .typeText(allowlistInput, '', { replace: true })
//});
//
//test('Confirm see modal and decline domain change when adding domain with subdomain to allowlist', async t => {
//  await t
//    .expect(Selector(allowlistTitle).innerText).eql('Domain Allowlist')
//    .typeText(allowlistInput, 'x.test.com', { replace: true })
//    .click(allowlistAddButton)
//    .typeText(allowlistInput, '', { replace: true })
//});