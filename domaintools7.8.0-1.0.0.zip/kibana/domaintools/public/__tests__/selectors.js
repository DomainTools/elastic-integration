/* please try to keep these alphabetized - for easier visual searching */

/* dashboard */
export const activeDomainsTitle = 'h2[data-id=activeDomainsTitle]';
export const activeTagsTitle = 'h2[data-id=activeTagsTitle]';
export const dashboardTitle = 'h2[data-id=dashboardTitle]';
export const dangerousDomainsTitle = 'button[data-id=dangerousDomainsTitle] > span.euiCard__content > span.euiTitle';
export const domainLookupsTitle = 'h2[data-id=domainLookupsTitle]';
export const eventsEnrichedTitle = 'button[data-id=eventsEnrichedTitle] > span.euiCard__content > span.euiTitle';
export const suspiciousDomainsTitle = 'button[data-id=suspiciousDomainsTitle] > span.euiCard__content > span.euiTitle';
export const threatPortfolioTitle = 'h2[data-id=threatPortfolioTitle]';
export const timeframeSelect = 'button[data-id=timeframeSelect]';
export const youngDomainsTitle = 'button[data-id=youngDomainsTitle] > span.euiCard__content > span.euiTitle';

/* domain profile */
export const domainProfileErrorForm = 'li.euiForm__error';
export const domainProfileLink = 'a[data-id=domainProfileHeaderLink]';
export const domainProfileModalCancelBtn = 'button[data-test-subj=confirmModalCancelButton]';
export const domainProfileModalConfirmBtn = 'button[data-test-subj=confirmModalConfirmButton]';
export const domainProfilePanelDomainName = 'h1[data-id=domainPanelDomainName]';
export const domainProfileSearchBtn = 'button[data-id=searchBtn]';
export const domainProfileSearchInput = 'input[data-id=searchTextInput]';
export const domainProfileTitle = 'h2[data-id=domainProfileTitle]';

/* app settings */
export const appSaveSettingsBtn = 'button[data-id=appSaveSettingsBtn]';
export const appSettingsErrorForm = 'li.euiForm__error';
export const batchSizeInput = 'input[data-id=batchSizeInput]';
export const disableCacheCheckbox = 'input[data-id=disableCacheCheckbox]';
export const domainAgeThresholdInput = 'input[data-id=domainAgeThresholdInput]';
export const enrichmentSettingsTitle = 'h1[data-id=enrichmentSettingsTitle]';
export const flushCacheBtn = 'button[data-id=flushCacheBtn]';
export const pivotThresholdInput = 'input[data-id=pivotThresholdInput]';
export const proximityScoreThresholdInput = 'input[data-id=proximityScoreThresholdInput]';
export const riskScoreThresholdInput = 'input[data-id=riskScoreThresholdInput]';
export const serviceUrlInput = 'input[data-id=serviceUrlInput]';
export const threatIntelligenceSettingsTitle = 'h1[data-id=threatIntelligenceSettingsTitle]';
export const threatProfileScoreThresholdInput = 'input[data-id=threatProfileScoreThresholdInput]';
export const ttlCacheInput = 'input[data-id=ttlCacheInput]';

/* navigation */
export const apiSettingsLink = 'button[data-id=apiSettingsBtn]';
export const appSettingsLink = 'button[data-id=appSettingsBtn]';
export const settingsHeaderLink = 'a[data-id=settingsHeaderLink]';
export const allowlistLink = 'button[data-id=allowlistBtn]';

/* allowlist */
export const allowlistAddButton = 'button[data-id=allowlistAddButton]';
export const allowlistErrorForm = 'li.euiForm__error';
export const allowlistInput = 'input[data-id=allowlistInput]';
export const allowlistRemoveAllButton = 'button.euiButton.euiButton--danger'
export const allowlistSelectAllCheckbox = 'input[data-test-subj=checkboxSelectAll]';
export const allowlistTitle = 'h2[data-id=allowlistTitle]';