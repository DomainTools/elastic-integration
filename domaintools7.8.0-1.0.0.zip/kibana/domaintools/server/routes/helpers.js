export function handleDomaintoolsServiceResponse(error, response, body) {
  const customErrorMessages = {
    "401": "DomainTools App is unable to reach its backend service components.  Please verify that the security key setup from the backend service is successful within Elastic. If the issue persists please email enterprisesupport@domaintools.com or CSM for technical assistance.",
    "403": "Invalid DomainTools API Username/Key found. If you need new API keys please reach out to enterprisesupport@domaintools.com",
    "404": "Connectivity issues within Elastic components. Either background service or Elasticsearch is down.  Please check and retry. If the issue persists please reach out to enterprisesupport@domaintools.com or CSM for technical assistance",
    "500": "Generic Server Errors encountered - please review latest 'dt-audit' index for detailed error message.",
  };
  let errorMessage = "ERROR";
  if (error) {
    errorMessage = error;
    if (error.code) {
      if(error.code === 'ECONNRESET'){
        errorMessage = "Connection timed out.";
      }
      if(error.code === "ECONNREFUSED") {
        errorMessage = "Unable to connect to background service.  Please check its status.";
      }
    }
  } else {
    if (response === undefined) {
      errorMessage = 'No response received from background service, most likely a timeout.';
    } else if (typeof body.error !== 'undefined') {
      errorMessage = body.error.message;
      if (body.error.code in customErrorMessages) {
        console.log(`ERROR: ${JSON.stringify(body.error)}`);
        errorMessage = customErrorMessages[body.error.code];
      }
    } else if (response.statusCode !== 200) {
      errorMessage = `Error: Status Code: ${response.statusCode}`;
      if (response.statusCode in customErrorMessages) {
        console.log(`ERROR: ${JSON.stringify(response)}`);
        errorMessage = customErrorMessages[response.statusCode];
      }
    } else {
      return {ok: true, data: body, error: null};
    }
  }
  return {ok: false, data: [], error: errorMessage};
}