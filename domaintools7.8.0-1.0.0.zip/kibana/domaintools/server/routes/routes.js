import request from 'request'
import { handleDomaintoolsServiceResponse } from './helpers';

export default function (server) {
  server.route({
    path: '/api/domaintools/test_connection',
    method: 'POST',
    handler(req) {
      try {
        const data = req.payload;
        let url = `${data.serviceUrl}/test_connection`
        return new Promise((resolve) => {
          let options = {
            url: url,
            method: 'POST',
            json: true,
            body: {
              security_key: data.securityKey,
              api_user: data.username,
              api_key: data.apiKey,
              proxy_enabled: data.enableProxy,
              proxy_server: data.proxyServer,
              proxy_port: data.proxyPort,
              custom_certificate_enabled: data.customCertificate,
              custom_certificate_path: data.customCertificatePath
            }
          };
          request(options, (error, response, body) => {
            const serviceResponse = handleDomaintoolsServiceResponse(error, response, body);
            if (serviceResponse.ok) {
              let iris_products = []
              let product = {}
              const endpoint = 'https://api.domaintools.com/v1/'
              if (serviceResponse.data.response.products) {
                for (product of serviceResponse.data.response.products) {
                  if (product['id'] === 'iris-investigate' || product['id'] === 'iris-enrich') {
                    product['endpoint'] = endpoint + product['id'];
                    iris_products.push(product);
                  }
                }
              }
              if (iris_products.length < 1) {
                let errorMessage = "This account does not have any Iris products, use a username/api key which has Iris products"
                resolve({ ok: false, data: [], error: errorMessage });
              } else {
                resolve({ ok: true, data: iris_products, error: null });
              }
            } else {
              resolve(serviceResponse);
            }
          });
        });
      } catch (error) {
        console.log("ERROR: TEST CONNECTION: ", error);
        return { ok: false, data: {}, error: error };
      }
    }
  });

  server.route({
    path: '/api/domaintools/refresh_settings',
    method: 'POST',
    handler(req) {
      try {
        const data = req.payload;
        let url = `${data.serviceUrl}/refresh_settings`;
        return new Promise((resolve) => {
          let options = {
            url: url,
            method: 'POST',
            json: true,
            body: { security_key: data.securityKey }
          };
          request(options, (error, response, body) => {
            const serviceResponse = handleDomaintoolsServiceResponse(error, response, body);
            if (serviceResponse.ok) {
              if (serviceResponse.data.message) {
                resolve({ ok: true, data: serviceResponse.data.message, error: null });
              }
            } else {
              resolve(serviceResponse);
            }
          });
        });
      } catch (error) {
        console.log("ERROR: REFRESH SETTINGS: ", error);
        return { ok: false, data: {}, error: error };
      }
    },
  });

  server.route({
    path: '/api/domaintools/adhoc_domain_profile',
    method: 'POST',
    handler(req) {
      try {
        const data = req.payload;
        let url = `${data.serviceUrl}/adhoc_domain_profile`;
        return new Promise((resolve) => {
          let options = {
            url: url,
            method: 'POST',
            json: true,
            body: {
              security_key: data.securityKey,
              domain: data.search_domain,
              first_check: data.first_check,
            },
          };
          request(options, (error, response, body) => {
            const serviceResponse = handleDomaintoolsServiceResponse(error, response, body);
            resolve(serviceResponse);
          });
        });
      } catch (error) {
        console.log("ERROR: ADHOC DOMAIN PROFILE: ", error);
        return { ok: false, data: {}, error: error };
      }
    },
  });

  server.route({
    path: '/api/domaintools/allowlist_validation',
    method: 'POST',
    handler(req) {
      try {
        const data = req.payload;
        let url = `${data.serviceUrl}/allowlist_validation`;
        return new Promise((resolve) => {
          let options = {
            url: url,
            method: 'POST',
            json: true,
            body: {
              security_key: data.securityKey,
              domains: data.domains
            },
          };
          request(options, (error, response, body) => {
            const serviceResponse = handleDomaintoolsServiceResponse(error, response, body);
            resolve(serviceResponse);
          });
        });
      } catch (error) {
        console.log("ERROR: ALLOWLIST VALIDATION: ", error);
        return { ok: false, data: {}, error: error };
      }
    },
  });

  server.route({
    path: '/api/domaintools/es/{index}/search',
    method: 'POST',
    handler: async (req) => {
      try {
        const documentData = req.payload;
        req.headers = {
          'Content-Type': 'application/json',
          'kbn-xsrf': 'kibana',
          'Accept': 'application/json, text/plain, */*'
        };
        const params = {
          index: req.params.index,
          body: documentData
        };
        const response = await server.plugins.elasticsearch.getCluster('data').callWithRequest(req, 'search', params);
        if (!response._shards) throw new Error(`Elasticsearch index not found: ${req.params.index}`);
        return { ok: true, data: response, error: null };
      } catch (error) {
        console.log(`ERROR: ES SEARCH in index ${req.params.index}: ${error}`);
        return { ok: false, data: {}, error: error };
      }
    }
  });

  server.route({
    path: '/api/domaintools/flush_cache',
    method: 'POST',
    handler: async (req) => {
      try {
        const data = req.payload;
        let url = `${data.serviceUrl}/flush_cache`;
        return new Promise((resolve) => {
          let options = {
            url: url,
            method: 'POST',
            json: true,
            body: {
              security_key: data.securityKey
            },
          };
          request(options, (error, response, body) => {
            const serviceResponse = handleDomaintoolsServiceResponse(error, response, body);
            if (serviceResponse.ok) {
              if (serviceResponse.data.message) {
                resolve({ ok: true, data: serviceResponse.data.message, error: null });
              }
            } else {
              resolve(serviceResponse);

            }
          });
        });
      } catch (error) {
        console.log("ERROR: ADHOC DOMAIN PROFILE: ", error);
        return { ok: false, data: {}, error: error };
      }
    },
  });

  const esPost = async (req) => {
    try {
      const documentData = req.payload;
      req.headers = {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
        'Accept': 'application/json, text/plain, */*'
      };
      const params = {
        index: req.params.index,
        body: documentData
      };
      if (req.params.documentId) {
        params['id'] = req.params.documentId;
      }
      const response = await server.plugins.elasticsearch.getCluster('data').callWithRequest(req, 'index', params);
      if (!response._shards) throw new Error(`Elasticsearch index not found: ${req.params.index}`);
      return { ok: true, data: response, error: null };
    } catch (error) {
      console.log("ERROR: ES Post: ", error);
      return { ok: false, error: error };
    }
  };

  const esUpdate = async (req) => {
    try {
      const documentData = req.payload;
      req.headers = {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
        'Accept': 'application/json, text/plain, */*'
      };
      const params = {
        index: req.params.index,
        body: documentData
      };
      if (req.params.documentId) {
        params['id'] = req.params.documentId;
      }
      const response = await server.plugins.elasticsearch.getCluster('data').callWithRequest(req, 'update', params);
      if (!response._shards) throw new Error(`Elasticsearch index not found: ${req.params.index}`);
      return { ok: true, data: response, error: null };
    } catch (error) {
      console.log("ERROR: ES Update: ", error);
      return { ok: false, error: error };
    }
  };

  const esGet = async (req) => {
    try {
      const params = {
        index: req.params.index,
        id: req.params.documentId
      };
      const response = await server.plugins.elasticsearch.getCluster('data').callWithRequest(req, 'get', params);
      return { ok: true, data: response, error: null };
    } catch (error) {
      console.log("ERROR: ES GET: ", error);
      return { ok: false, data: {}, error: error };
    }
  }

  const esBulk = async (req) => {
    try {
      const documentData = req.payload;
      req.headers = {
        'Content-Type': 'application/json',
        'kbn-xsrf': 'kibana',
        'Accept': 'application/json, text/plain, */*'
      };
      const params = {
        body: documentData
      };
      const response = await server.plugins.elasticsearch.getCluster('data').callWithRequest(req, 'bulk', params);
      return { ok: true, data: response, error: null };
    } catch (error) {
      console.log("ERROR: ES Bulk: ", error);
      return { ok: false, error: error };
    }
  };

  server.route({
    path: '/api/domaintools/update/es/{index}/{documentId}',
    method: 'PUT',
    handler: esUpdate
  });

  server.route({
    path: '/api/domaintools/es/{index}/{documentId}',
    method: 'GET',
    handler: esGet
  });
  
  server.route({
    path: '/api/domaintools/es/{index}/{documentId}',
    method: 'POST',
    handler: esPost
  });

  server.route({
    path: '/api/domaintools/es/{index}',
    method: 'POST',
    handler: esPost
  });

  server.route({
    path: '/api/domaintools/allowlist',
    method: 'POST',
    handler: esBulk
  });
}
