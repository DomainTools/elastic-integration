import { resolve } from 'path';
import { existsSync } from 'fs';
import domainToolsRoutes from './server/routes/routes';

export default function(kibana) {
  return new kibana.Plugin({
    require: ['elasticsearch'],
    name: 'domaintools',
    publicDir: resolve(__dirname, 'public'),
    uiExports: {
      app: {
        title: 'DomainTools',
        description: 'DomainTools Iris integration',
        main: 'plugins/domaintools/app',
        icon: 'plugins/domaintools/images/domaintools.svg',
      },
      hacks: ['plugins/domaintools/hack'],
      styleSheetPaths: [resolve(__dirname, 'public/app.css')].find(p => existsSync(p)),
    },

    config(Joi) {
      return Joi.object({
        enabled: Joi.boolean().default(true),
      }).default();
    },

    // eslint-disable-next-line no-unused-vars
    init(server, options) {
      // Add server routes and initialize the plugin here
      domainToolsRoutes(server);
    },
  });
}
